<?php
session_start();
include "koneksi.php";
$sql=mysql_query("SELECT * FROM user WHERE id_user='$_SESSION[namauser]' AND password='$_SESSION[passuser]'");
$level=mysql_num_rows($sql);
$r=mysql_fetch_array($sql);

date_default_timezone_set('Asia/Jakarta');
//Menampilkan tanggal hari ini dalam bahasa Indonesia dan English
$namaHari   = array("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu","Minggu");
$namaBulan = array("Januari", "Februari", "Maret", "April", "Mei",  "Juni", "Juli", "Agustus", "September", "Oktober", "November",  "Desember");
$sekarang = $namaHari[date('N')] . ", " . date('j') . " " . $namaBulan[(date('n')-1)] . " " . date('Y');
?>
<center >
<h1>Upload Download File</h1><br>
<form enctype="multipart/form-data" action="upload/upload.php" method="POST" id=upload>
    <input type="hidden" name="id" value="<?php echo "$r[nama_lengkap]";?>" />
    <input type="hidden" name="tgl" value="<?php echo "$sekarang";?>" />
    <input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
    Pilih File: <input name="userfile" type="file" />
    <input type="submit" value="Upload" /> max. 10 Mb
</form>
</center>
<?php

if ($_SESSION['leveluser']=='admin'){
echo "
	<strong align=left>File yang dimonitoring $r[nama_lengkap] </strong>
   <table border=1 	width='100%'><tr>
   <th width=10>No</th><th>Tgl Upload</th><th>Oleh</th><th>Nama File</th><th>Ukuran</th><th width=15 colspan=2>Aksi</th></tr>";
	$query  = "SELECT * FROM upload";
	$hasil  = mysql_query($query);
	$no=1;
	while($data = mysql_fetch_array($hasil)){
		echo "<tr>
		<td>$no. </td>
		<td><b>".$data['tgl']."</td>
		<td><b>".$data['id_user']." ".$data['nama_lengkap']."</td>
		<td><b>".$data['name']."</b></td>
		<td>".$data['size']." bytes</td>
		<td align=center>
		<a href='upload/download.php?id=".$data['id_upload']."'><img src='upload/img/d.png' title=Download border='0' height='15' width='15'/></a>
		<a href='./upload/hapus.php?hapus&id=".$data['id_upload']."'><img src='upload/img/del.png' title=Hapus border='0' height='15' width='15'/></a></td></tr>";
			$no++;
		}
		
 echo "</table>";
		}
		
		elseif ($_SESSION['leveluser']=='user'){
echo "
   <strong align=left>File milik $r[nama_lengkap] </strong>
   <table border=1 	width='100%'><tr>
   <th width=10>No</th><th>Tanggal Upload</th><th>Nama File</th><th>Ukuran</th><th width=15 colspan=2>Aksi</th></tr>";
	$query  = "SELECT * FROM upload where id_user='$r[nama_lengkap]'";
	$hasil  = mysql_query($query);
	$no=1;
	while($data = mysql_fetch_array($hasil)){
		echo "<tr>
		<td>$no. </td>
		<td>".$data['tgl']."</td>
		<td><b>".$data['name']."</b></td>
		<td>".$data['size']." bytes</td>
		<td align=center>
		<a href='upload/download.php?id=".$data['id_upload']."'><img src='upload/img/d.png' title=Download border='0' height='15' width='15'/></a>
		</td></tr>";
			$no++;
		}
		
 echo "</table>";
		}
	
 ?>
