<?php
 include "koneksi.php";
$uploaddir = 'data/';
$fileName = $_FILES['userfile']['name'];     
$tmpName  = $_FILES['userfile']['tmp_name']; 
$fileSize = $_FILES['userfile']['size'];
$fileType = $_FILES['userfile']['type'];
$id = $_POST['id'];
$tgl = $_POST['tgl'];
 

 
$query = "SELECT count(*) as jum FROM upload WHERE name = '$fileName'";
$hasil = mysql_query($query);
$data  = mysql_fetch_array($hasil);
 
if(empty ($fileName)){
	echo "<b>Tentukan File yang akan diupload</b> Tidak Boleh Kosong<br>";
	echo "<input type=button value=Kembali onclick=self.history.back()>";
	}
else{

if ($data['jum'] > 0)
{
   $query = "UPDATE upload SET size = '$fileSize' WHERE name = '$fileName'";
}
else $query = "INSERT INTO upload (id_user, tgl, name, size, type) VALUES ('$id', '$tgl', '$fileName', '$fileSize', '$fileType')";
 
mysql_query($query);
$uploadfile = $uploaddir . $fileName;
 
// proses upload file ke folder 'data'
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    header('location:../admin.php?pilih=upload');
} else {
    echo "File gagal diupload";
	echo "<input type=button value=Kembali onclick=self.history.back()>";
	
}  
  
  }
?>














































