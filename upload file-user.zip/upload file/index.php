
<center>
<h1>Upload/Download File</h1><br>
<form enctype="multipart/form-data" action="upload.php" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="3000000" />
    Pilih File: <input name="userfile" type="file" />
    <input type="submit" value="Upload" />
</form>
<?php
include "koneksi.php";
 echo "
   <table border=1 	width='40%'><tr>
   <th width=10>No</th><th>File Name</th><th>Size</th><th width=15 colspan=2>Download</th></tr>";
	
	$query  = "SELECT * FROM uploadfile";
	$hasil  = mysql_query($query);
	$no=1;
	while($data = mysql_fetch_array($hasil)){
		echo "<tr>
		<td>$no. </td>
		<td><b>".$data['name']."</b></td>
		<td>".$data['size']." bytes</td>
		<td align=center>
		<a href='download.php?id=".$data['id_upload']."'><img src='img/d.png' title=Download border='0' height='15' width='15'/></a>
		<a href='hapus.php?id=".$data['id_upload']."'><img src='img/del.png' title=Hapus border='0' height='15' width='15'/></a></td></tr>";
			$no++;
		}
 echo "</table>";
?>
</center>
