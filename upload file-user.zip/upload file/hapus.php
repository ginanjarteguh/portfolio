<?php
include "koneksi.php";

	$id      = $_GET['id'];
    // membaca nama file yang akan dihapus berdasarkan id
    $query   = "SELECT * FROM upload WHERE id_upload = '$id'";
    $hasil   = mysql_query($query);
    $data    = mysql_fetch_array($hasil);
    $namaFile = $data['name'];
 
    // query untuk menghapus informasi file berdasarkan id
    $query = "DELETE FROM upload WHERE id_upload = $id";
    mysql_query($query);
 
    // menghapus file dalam folder sesuai namanya	
    unlink("data/".$namaFile);
	header('location:../admin.php?pilih=upload'); 
?>














































