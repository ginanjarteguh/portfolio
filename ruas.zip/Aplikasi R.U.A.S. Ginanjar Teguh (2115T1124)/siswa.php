<html>
<head>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<title>DATA SISWA</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fid_siswa			= "";	
$fid_jurusan		= "";	
$ftahun_ajaran		= "";	
$fnis				= "";	
$fnama				= "";	
$ftingkat			= "";	


?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM siswa where id_siswa='$_GET[id]'");
$r		= mysql_fetch_array($tampil);
$ftitle			= "<h1>UBAH DATA</h1>";	
$fid_siswa		= $r['id_siswa'];	
$fid_jurusan	= $r['id_jurusan'];	
$ftahun_ajaran	= $r['tahun_ajaran'];	
$fnis			= $r['nis'];	
$fnama			= $r['nama'];	
$ftingkat		= $r['tingkat'];	

}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>INPUT DATA SISWA</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fid_siswa ?>">
	<?php } 	?>
	<table>
	<h3 align="center">DAFTAR SISWA</h3>
	<tr><td>ID SISWA</td><td><input type="text" name="id_siswa" value="<?= $fid_siswa ?>"></td></tr>
	<tr><td>ID JURUSAN</td><td><input type="text" name="id_jurusan" value="<?= $fid_jurusan ?>"></td></tr>
	<tr><td>TAHUN AJARAN</td><td><input type="text" name="tahun_ajaran" value="<?= $ftahun_ajaran ?>"></td></tr>
	<tr><td>NIS</td><td><input type="text" name="nis" value="<?= $fnis ?>"></td></tr>
	<tr><td>NAMA</td><td><input type="text" name="nama" value="<?= $fnama ?>"></td></tr>
	<tr><td>TINGKAT</td><td>
			<select name="tingkat">
				<?php if($_GET["op"] == "edit"){ ?>
				<option value="<?= $ftingkat ?>"><?= $ftingkat ?></option>
				<?php }else{ ?>
				<option> - Pilih Tingkat - </option>
				<?php } ?>
				<option value="X">X</option>
				<option value="XI">XI</option>
				<option value="XII">XII</option>
			</select>
			
	</td></tr>

	<tr><td colspan="2" align="center"><input type="submit" name="submit" 	value="Register"> <input  type="button" value="Cancel" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['id_siswa'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO siswa(id_siswa, id_jurusan, tahun_ajaran ,nis, nama, tingkat) VALUES ('$_POST[id_siswa]','$_POST[id_jurusan]','$_POST[tahun_ajaran]','$_POST[nis]','$_POST[nama]','$_POST[tingkat]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE siswa SET id_siswa = '$_POST[id_siswa]',id_jurusan = '$_POST[id_jurusan]',tahun_ajaran = '$_POST[tahun_ajaran]',nis = '$_POST[nis]',nama = '$_POST[nama]',tingkat = '$_POST[tingkat]' WHERE id_siswa  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM siswa WHERE id_siswa='$_GET[id]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<center>
<h1>DAFTAR SISWA</h1>
<a href='<?= $_SERVER['PHP_SELF'] ?>'>Index</a> | <a href='?op=tambah'>Tambah </a> | <a href='login/admin.php'>Beranda</a><br><br>
</center>
<table width="70%" border="1" style="margin: 0 auto;">
<tr>
<td>No</td>
<td>ID JURUSAN</td>
<td>TAHUN AJARAN</td>
<td>NIS</td>
<td>NAMA</td>
<td>TINGKAT</td>
<td>Operasi</td>
</tr>

<?php
	$tampil=mysql_query("SELECT * FROM siswa ORDER BY id_siswa ASC"); // query sql
	$no=1;
	while ($r=mysql_fetch_array($tampil)){ 							//perulangan menampilkan data
	echo "
			<tr>
				<td>$no</td>
				<td>$r[id_jurusan]</td>
				<td>$r[tahun_ajaran]</td>
				<td>$r[id_siswa]</td>
				<td>$r[nama]</td>
				<td>$r[tingkat]</td>
				<td>
				<a href='?op=edit&id=$r[id_siswa]'>Edit</a>
				<a href='?op=hapus&id=$r[id_siswa]'>Hapus</a>
				</td>
			</tr>
		";
	$no++;
	}
?>
</table>
</body>
</html>
