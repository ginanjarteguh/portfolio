<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<title>NILAI MAPEL</title>
<h1>INPUT NILAI MAPEL</h1>
</head>
<body>
<hr>
<table align='center'>
<tr>
<td><button onclick="window.location.href='../login/guru.php'">BERANDA</button></td>
<td><button onclick="window.location.href='input.php'">KEMBALI</button></td>
<td><button onclick="window.location.href='../index.php'">KELUAR</button></td>
<tr>
</table>
<hr>
<form method="post" action="update.php">
<div style="border:1px solidgrey; width:1336px;height:400px;overflow-y:scroll;overflow-x:scroll;">
<table border="0"  class="table1">
<tr><th>No</th><th>NIS</th><th>Nama</th><th>Pend.Kewarganegaraan</th><th>Pend. Agama Budi Pekerti</th><th>BahasaIndonesia</th><th>Bahasa Inggris</th><th>Matematika</th><th>Pend. Jasmani Kesehatan</th><th>Seni Budaya</th><th>IPS</th>
<th>Kewirausahan</th><th>KKPI</th><th>Bahasa Jawa</th><th>IPA</th><th>Komp.Dasar Kejuruan</th><th>Kompetensi Kejuruan</th><th>Muatan Lokal Produktif</th></tr>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");

// membaca kode matakuliah yang disubmit dari formnilai.php
$TAName 	= $_POST['TA'];
$kelasName	= $_POST['kelas'];
// menampilkan data nim dan nilai mahasiswa yang mengambil matakuliah berdasarkan kode MK
$query = "SELECT * FROM nilai WHERE id_ta='$TAName ' AND id_kelas='$kelasName'";

$hasil = mysql_query($query);

// inisialisasi counter
$i = 1;
while ($data = mysql_fetch_array($hasil))
{
   echo "<tr>	
				<td>".$i."</td>
				<td>".$data['id_siswa']."</td>
				<td>".$data['Nama']."</td>
				
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n101".$i."' value='".$data['n101']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n102".$i."' value='".$data['n102']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n103".$i."' value='".$data['n103']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n104".$i."' value='".$data['n104']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n105".$i."' value='".$data['n105']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n106".$i."' value='".$data['n106']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n107".$i."' value='".$data['n107']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n108".$i."' value='".$data['n108']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n109".$i."' value='".$data['n109']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n110".$i."' value='".$data['n110']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n111".$i."' value='".$data['n111']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n112".$i."' value='".$data['n112']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n113".$i."' value='".$data['n113']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n114".$i."' value='".$data['n114']."' />
				</td>
				<td><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='n115".$i."' value='".$data['n115']."' />
				</td>
				
				
		</tr></div>";
   $i++;
}
$jumMhs = $i-1;
?>
</table>

<br>
<table align="center">
<th>
<input type="hidden" name="n" value="<?php echo $jumMhs ?>" />
<input type="hidden" name="id_ta" value="<?php echo $TAName;?>">
<input type="submit" value="Update" name="submit" />
</th>
</table>
</div>
</form>
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>