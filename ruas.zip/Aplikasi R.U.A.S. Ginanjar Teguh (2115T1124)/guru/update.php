<html>
<title>
UPDATE NILAI
</title>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<br>
</head>
<body>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");

// membaca jumlah mahasiswa (n) dari submit.php
$jumMhs = $_POST['n'];

// membaca kode MK yang akan diupdate
$kodeTA = $_POST['id_ta'];

// proses looping untuk membaca nilai dan nim mahasiswa dari form, serta menjalankan query update
for ($i=1; $i<=$jumMhs; $i++)
{
   // membaca nim mahasiswa ke-i, i = 1, 2, 3, ..., n
   $nimMhs = $_POST['siswa'.$i];

   // membaca nilai mahasiswa ke-i, i = 1, 2, 3, ..., n
   $n101  = $_POST['n101'.$i];
   $n102  = $_POST['n102'.$i];
   $n103  = $_POST['n103'.$i];
   $n104  = $_POST['n104'.$i];
   $n105  = $_POST['n105'.$i];
   $n106  = $_POST['n106'.$i];
   $n107  = $_POST['n107'.$i];
   $n108  = $_POST['n108'.$i];
   $n109  = $_POST['n109'.$i];
   $n110  = $_POST['n110'.$i];
   $n111  = $_POST['n111'.$i];
   $n112  = $_POST['n112'.$i];
   $n113  = $_POST['n113'.$i];
   $n114  = $_POST['n114'.$i];
   $n115  = $_POST['n115'.$i];
   $n116  = $_POST['n116'.$i];
   $n117  = $_POST['n117'.$i];
   $n118  = $_POST['n118'.$i];
  

   // update nilai mahasiswa ke-i, i = 1, 2, 3, ..., n
   $query = "UPDATE nilai 
   SET 
   n101 = '$n101',
   n102 = '$n102',
   n103 = '$n103',
   n104 = '$n104',
   n105 = '$n105',
   n106 = '$n106',
   n107 = '$n107', 
   n108 = '$n108',
   n109 = '$n109',
   n110 = '$n110',
   n111 = '$n111',
   n112 = '$n112',
   n113 = '$n113',
   n114 = '$n114',
   n115 = '$n115',
   n116 = '$n116',
   n117 = '$n117',
   n118 = '$n118'
   
   
   WHERE id_siswa = '$nimMhs'";
   mysql_query($query);
}
echo '<br><br><br><h1>Nilai berhasil disimpan klik <a href="input.php">Disini</a> untuk melanjutkan</h1>

';

//header('location:input.php');

?>
</body>
</html>