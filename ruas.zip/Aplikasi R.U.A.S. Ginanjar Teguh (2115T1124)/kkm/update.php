<html>
<title>
UPDATE NILAI
</title>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<br>
</head>
<body>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");

// membaca jumlah mahasiswa (n) dari submit.php
$jumMhs = $_POST['n'];

// membaca kode MK yang akan diupdate
$kodemapel = $_POST['id_mapel'];

// proses looping untuk membaca nilai dan nim mahasiswa dari form, serta menjalankan query update
for ($i=1; $i<=$jumMhs; $i++)
{
   // membaca nim mahasiswa ke-i, i = 1, 2, 3, ..., n
   //$nimMhs = $_POST['mhs'.$i];

   // membaca nilai mahasiswa ke-i, i = 1, 2, 3, ..., n
   $kkm  = $_POST['kkm'.$i];

   // update nilai mahasiswa ke-i, i = 1, 2, 3, ..., n
   $query = "UPDATE mapel SET kkm = $kkm WHERE id_mapel = '$kodemapel'";
   mysql_query($query);
}

echo '<br><br><br><h1>Nilai berhasil disimpan klik <a href="input.php">Disini</a> untuk melanjutkan</h1><br>
';
//header('location:input.php');

?>
</body>
</html>