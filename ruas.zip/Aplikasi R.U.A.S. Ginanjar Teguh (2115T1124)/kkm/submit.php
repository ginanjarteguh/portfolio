<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<title>KKM</title>
<h1>INPUT KKM</h1>
</head>
<body align='center'>
<hr>
<table align="center">
<tr>
<td><button onclick="window.location.href='../login/guru.php'">BERANDA</button></td>
<td><button onclick="window.location.href='../kkm/input.php'">KEMBALI</button></td>
<td><button onclick="window.location.href='../index.php'">KELUAR</button></td>
<tr>
</table>
<hr>
<form method="post" action="update.php">
<table border="1" align="center">
<tr><th>No</th><th>NIM</th><th>KKM</th></tr>

<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");

// membaca kode matakuliah yang disubmit dari input.php
$kodemapel = $_POST['mapel'];

// menampilkan data nim dan nilai mahasiswa yang mengambil matakuliah berdasarkan kode mapel
$query = "SELECT nama_mapel, kkm FROM mapel WHERE id_mapel = '$kodemapel'";

$hasil = mysql_query($query);

// inisialisasi counter
$i = 1;
while ($data = mysql_fetch_array($hasil))
{
   echo "<tr>
			<td>".$i."</td>
			<td>".$data['nama_mapel']."</td>
			<td><input type='hidden' name='mapel".$i."' value='".$data['id_mapel']."' />
				<input type='text' name='kkm".$i."' value='".$data['kkm']."'/>
			</td>
		</tr>";
   $i++;
}
$jumMhs = $i-1;
?>
</table>
<table align="center">
<tr>
<td colspan="3">
<input type="submit" value="Update" name="submit" />
</td>
</tr>
</table>
<br>
<input type="hidden" name="n" value="<?php echo $jumMhs ?>" />
<input type="hidden" name="id_mapel" value="<?php echo $kodemapel;?>">
</form>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>  
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>