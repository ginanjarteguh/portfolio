<html>
<head>
<br>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<title>DATA JURUSAN</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fid_jurusan		= "";	
$fkd_jurusan		= "";	
$fjurusan			= "";	

?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM jurusan where id_jurusan='$_GET[id]'");
$r		= mysql_fetch_array($tampil);
$ftitle				= "<h1>UBAH DATA</h1>";	
$fid_jurusan		= $r['id_jurusan'];	
$fkd_jurusan		= $r['kd_jurusan'];	
$fjurusan			= $r['jurusan'];	

}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>INPUT DATA JURUSAN</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fid_jurusan ?>">
	<?php } 	?>
	<table>
	<h3 align="center">DATA JURUSAN</h3>
	<tr><td>ID JURUSAN</td><td><input type="text" name="id_jurusan" value="<?= $fid_jurusan ?>"></td></tr>
	<tr><td>KD JURUSAN</td><td><input type="text" name="kd_jurusan" value="<?= $fkd_jurusan ?>"></td></tr>
	<tr><td>JURUSAN</td><td><input type="text" name="jurusan" value="<?= $fjurusan ?>"></td></tr>
	</td></tr>
	<tr><td colspan="2" align="center"><input type="submit" name="submit" 	value="Register"> <input  type="button" value="Cancel" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['id_jurusan'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO jurusan(id_jurusan, kd_jurusan, jurusan) VALUES ('$_POST[id_jurusan]','$_POST[kd_jurusan]','$_POST[jurusan]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE jurusan SET id_jurusan = '$_POST[id_jurusan]',kd_jurusan = '$_POST[kd_jurusan]',jurusan = '$_POST[jurusan]' WHERE id_jurusan  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM jurusan WHERE id_jurusan='$_GET[id]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<center>
<h1>JURUSAN</h1>
<a href='<?= $_SERVER['PHP_SELF'] ?>'>Index</a> | <a href='?op=tambah'>Tambah </a> | <a href='login/admin.php'>Beranda</a><br><br>
</center>
<table width="70%" border="1" style="margin: 0 auto;">
<tr>
<th>No</th>
<th>ID JURUSAN</th>
<th>KODE JURUSAN</th>
<th>JURUSAN</th>
<th>OPSI</th>
</tr>

<?php
	$tampil=mysql_query("SELECT * FROM jurusan ORDER BY id_jurusan ASC"); // query sql
	$no=1;
	while ($r=mysql_fetch_array($tampil)){ 							//perulangan menampilkan data
	echo "
			<tr>
				<td>$no</td>
				<td>$r[id_jurusan]</td>
				<td>$r[kd_jurusan]</td>
				<td>$r[jurusan]</td>
				<td>
				<a href='?op=edit&id=$r[id_jurusan]'>Edit</a>
				<a href='?op=hapus&id=$r[id_jurusan]'>Hapus</a>
				</td>
			</tr>
		";
	$no++;
	}
?>
</table>
</body>
</html>
