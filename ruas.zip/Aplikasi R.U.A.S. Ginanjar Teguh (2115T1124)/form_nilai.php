<html>
<head>
<br>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<title>DATA SISWA</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fid_nilai			= "";	
$fid_ta				= "";	
$fid_kelas			= "";
$fid_jurusan		= "";
//$fjurusan			= "";	
//$fid_mapel			= "";	
$fid_siswa			= "";
$fnama				= "";	
//$fnilai				= "";	


?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM nilai where id_nilai='$_GET[id_nilai]'");
$r		= mysql_fetch_array($tampil);
$ftitle		= "<h3>UPDATE NILAI</h3>";	
$fid_nilai	= $r['id_nilai'];	
$fid_ta		= $r['id_ta'];	
$fid_kelas	= $r['id_kelas'];	
$fid_jurusan= $r['id_jurusan'];	
//$fjurusan	    = $r['jurusan'];	
//$fid_mapel	= $r['id_mapel'];	
$fid_siswa	= $r['id_siswa'];
$fnama		= $r['Nama'];	
//$fnilai		= $r['nilai'];	

}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>FORM INPUT DATA SISWA</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fid_nilai ?>">
	<?php } 	?>
	<table>
	<tr><td>ID NILAI</td><td><input type="text" name="id_nilai" value="<?= $fid_nilai ?>"></td></tr>
	<tr><td>TAHUN AJARAN</td><td><input type="text" name="id_ta" value="<?= $fid_ta?>"></td></tr>
	<tr><td>ID KELAS</td><td><input type="text" name="id_kelas" value="<?= $fid_kelas ?>"></td></tr>
	<tr><td>ID JURUSAN</td><td><input type="text" name="id_jurusan" value="<?= $fid_jurusan ?>"></td></tr>
	<tr><td>NIS</td><td><input type="text" name="id_siswa" value="<?= $fid_siswa ?>"></td></tr>
	<tr><td>NAMA</td><td><input type="text" name="Nama" value="<?= $fnama ?>"></td></tr>
	<tr><td colspan="2" align="center"><input type="submit" name="submit" 	value="INPUT"> <input  type="button" value="CANCEL" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['id_nilai'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO nilai(id_nilai, id_ta, id_kelas, id_jurusan, id_siswa, Nama) VALUES ('$_POST[id_nilai]','$_POST[id_ta]','$_POST[id_kelas]','$_POST[id_jurusan]','$_POST[id_siswa]','$_POST[Nama]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE nilai SET id_nilai = '$_POST[id_nilai]',id_ta = '$_POST[id_ta]',id_kelas = '$_POST[id_kelas]',id_jurusan = '$_POST[id_jurusan]',id_siswa = '$_POST[id_siswa]',Nama = '$_POST[Nama]' WHERE id_nilai  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM nilai WHERE id_nilai='$_GET[id_nilai]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<center>
<h1>DAFTAR SISWA</h1>
<a href='<?= $_SERVER['PHP_SELF'] ?>'>Index</a> | <a href='?op=tambah'>Tambah </a> | <a href='login/admin.php'>Beranda</a><br><br>
</center>
<table width="70%" border="1" style="margin: 0 auto;">
<tr>
<th>ID NILAI</th>
<th>TAHUN AJARAN</th>
<th>KELAS</th>
<th>ID JURUSAN</th>
<th>NIS</th>
<th>NAMA</th>
<th>Operasi</th>
</tr>

<?php
	$tampil=mysql_query("SELECT * FROM nilai ORDER BY id_nilai ASC"); // query sql
	//$no=1;
	while ($r=mysql_fetch_array($tampil)){ 							//perulangan menampilkan data
	echo "
			<tr>
				<td>$r[id_nilai]</td>
				<td>$r[id_ta]</td>
				<td>$r[id_kelas]</td>
				<td>$r[id_jurusan]</td>
				<td>$r[id_siswa]</td>
				<td>$r[Nama]</td>
				<td>
				<a href='?op=edit&id_nilai=$r[id_nilai]'>Edit</a>
				<a href='?op=hapus&id_nilai=$r[id_nilai]'>Hapus</a>
				</td>
			</tr>
		";
	$no++;
	}
?>
</table>
</body>
</html>
