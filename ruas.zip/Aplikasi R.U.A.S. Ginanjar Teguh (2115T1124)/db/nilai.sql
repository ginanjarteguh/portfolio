-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2017 at 05:25 AM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nilai`
--

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `kd_jurusan` varchar(50) NOT NULL DEFAULT '0',
  `jurusan` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `kd_jurusan`, `jurusan`) VALUES
(118, 'XIIAK', 'Akuntansi'),
(119, 'XIIAP', 'Adm. Perkantoran'),
(121, 'XIIPM', 'Pemasaran');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `id_kelas` int(6) NOT NULL,
  `tingkat` enum('X','XI','XII') NOT NULL,
  `kode_kelas` varchar(20) NOT NULL,
  `id_jurusan` int(13) NOT NULL,
  `nama_kelas` varchar(30) NOT NULL,
  `id_pegawai` int(10) NOT NULL COMMENT 'walikelas'
) ENGINE=InnoDB AUTO_INCREMENT=12122 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `tingkat`, `kode_kelas`, `id_jurusan`, `nama_kelas`, `id_pegawai`) VALUES
(12118, 'XII', 'XII AK', 118, 'Akuntansi', 1001),
(12119, 'XII', 'XII AP', 119, 'Adm. Perkantoran', 1004),
(12121, 'XII', 'XII PM', 121, 'Pemasaran', 1009);

-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE IF NOT EXISTS `mapel` (
  `id_mapel` int(6) NOT NULL,
  `kd_mapel` varchar(50) NOT NULL DEFAULT '0',
  `nama_mapel` varchar(50) NOT NULL,
  `kkm` varchar(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1154 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mapel`
--

INSERT INTO `mapel` (`id_mapel`, `kd_mapel`, `nama_mapel`, `kkm`) VALUES
(101, 'Pkn', 'Pendidikan Kewarganegaraan', '78'),
(102, 'PAK', 'Pendidikan Agama Budi Pekerti', '75'),
(103, 'B.Ind', 'Bahasa Indonesia', '78'),
(104, 'B.Ing', 'Bahasa Inggris', '78'),
(105, 'Mat', 'Matematika', '75'),
(106, 'Penjaskes', 'Pendidikan Jasmani & Kesehatan', '75'),
(107, 'SB', 'Seni Budaya', '75'),
(108, 'IPS', 'Ilmu Pengetahuan Sosial', '75'),
(109, 'KWU', 'Kewirausahaan', '75'),
(110, 'KKPI', 'Keter Komp.& Peng. Informasi', '75'),
(111, 'B.Ja', 'Bahasa Jawa', '75'),
(112, 'IPA', 'Ilmu Pengetahuan Alam', '75'),
(1131, 'Prod.AK(1)', 'Kompetensi Dasar Kejuruan Akuntansi', '87'),
(1132, 'Prod.AK(2)', 'Kompetensi Kejuruan Akuntansi', '87'),
(1133, 'Prod.AK(3)', 'Muatan Lokal Produktif Akuntansi', '87'),
(1141, 'Prod.AP(1)', 'Kompetensi Dasar Kejuruan Adm. Perkantoran', '87'),
(1142, 'Prod.AP(2)', 'Kompetensi Kejuruan Adm. Perkantoran', '87'),
(1143, 'Prod.AP(3)', 'Muatan Lokal Adm. Perkantoran', '87'),
(1151, 'Prod.PM(1)', 'Kompetensi Dasar Kejuruan Pemasaran', '87'),
(1152, 'Prod.PM(2)', 'Kompetensi Kejuruan Pemasaran', '87'),
(1153, 'Prod.PM(3)', 'Muatan Lokal Pemasaran', '87');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
  `id_nilai` int(6) NOT NULL,
  `id_ta` int(4) NOT NULL,
  `id_kelas` int(6) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `id_siswa` int(4) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `ijin` int(3) NOT NULL,
  `sakit` int(3) NOT NULL,
  `alpha` int(3) NOT NULL,
  `kelakuan` enum('A','B','C') NOT NULL,
  `kerajinan` enum('A','B','C') NOT NULL,
  `kerapian` enum('A','B','C') NOT NULL,
  `n101` varchar(3) NOT NULL,
  `n102` varchar(3) NOT NULL,
  `n103` varchar(3) NOT NULL,
  `n104` varchar(3) NOT NULL,
  `n105` varchar(3) NOT NULL,
  `n106` varchar(3) NOT NULL,
  `n107` varchar(3) NOT NULL,
  `n108` varchar(3) NOT NULL,
  `n109` varchar(3) NOT NULL,
  `n110` varchar(3) NOT NULL,
  `n111` varchar(3) NOT NULL,
  `n112` varchar(3) NOT NULL,
  `n113` varchar(3) NOT NULL,
  `n114` varchar(3) NOT NULL,
  `n115` varchar(3) NOT NULL,
  `n116` varchar(3) NOT NULL,
  `n117` varchar(3) NOT NULL,
  `n118` varchar(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id_nilai`, `id_ta`, `id_kelas`, `id_jurusan`, `id_siswa`, `Nama`, `ijin`, `sakit`, `alpha`, `kelakuan`, `kerajinan`, `kerapian`, `n101`, `n102`, `n103`, `n104`, `n105`, `n106`, `n107`, `n108`, `n109`, `n110`, `n111`, `n112`, `n113`, `n114`, `n115`, `n116`, `n117`, `n118`) VALUES
(1, 20161, 12118, 118, 7452, 'Anugrah Bekti Pamularsih', 1, 2, 1, 'A', 'B', 'C', '78', '78', '78', '78', '89', '89', '89', '90', '89', '89', '89', '78', '78', '78', '78', '', '', ''),
(2, 20161, 12118, 118, 7453, 'Anggi Pertiwi', 1, 1, 1, 'C', 'B', 'A', '80', '80', '80', '80', '89', '89', '89', '78', '67', '78', '57', '78', '67', '78', '78', '', '', ''),
(3, 20161, 12118, 118, 7454, 'Dian Retnosari', 2, 1, 1, 'A', 'B', 'C', '80', '80', '80', '80', '89', '89', '89', '67', '78', '98', '67', '87', '67', '78', '76', '', '', ''),
(4, 20161, 12118, 118, 7455, 'Dwi Rahmawati', 1, 1, 1, 'C', 'B', 'A', '76', '64', '75', '89', '76', '89', '76', '98', '67', '89', '76', '87', '90', '56', '87', '', '', ''),
(5, 20161, 12118, 118, 7456, 'Efita Pebriani', 0, 0, 0, 'A', 'A', 'A', '87', '87', '87', '87', '87', '65', '78', '45', '78', '90', '65', '78', '45', '90', '87', '', '', ''),
(6, 20161, 12119, 119, 7471, 'Anggun Diah Pramesti', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, 20161, 12119, 119, 7472, 'Anggun Melliasari Gadis P', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, 20161, 12119, 119, 7473, 'Aninda Tika Chrisnadetta', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, 20161, 12119, 119, 7478, 'Fitria Nur Aini', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, 20161, 12119, 119, 7479, 'Heni Puji Indarti', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, 20161, 12121, 121, 7491, 'Ari Fitrianingsih', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, 20161, 12121, 121, 7493, 'Ayu Lesiana', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, 20161, 12121, 121, 7494, 'Bety Dewi Rusiana', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, 20161, 12121, 121, 7497, 'Fitriani', 0, 0, 0, 'A', 'A', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int(10) NOT NULL,
  `nama_guru` varchar(30) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `status` enum('Guru','Karyawan') NOT NULL,
  `tingkat` enum('X','XI','XII') NOT NULL,
  `id_jurusan` enum('118','119','121') NOT NULL,
  `id_mapel` int(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1017 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama_guru`, `nip`, `status`, `tingkat`, `id_jurusan`, `id_mapel`) VALUES
(1001, 'Asih Widarjanti, S.Pak', '10012001', 'Guru', 'XII', '118', 102),
(1002, 'Windu Widayati, S.Pd', '10021997', 'Guru', 'XII', '118', 101),
(1003, 'Heny Puspowati, S.Pd', '10032008', 'Guru', 'XII', '118', 105),
(1004, 'Febriana Festianti, S.Pd', '10042004', 'Guru', 'XII', '118', 104),
(1005, 'Netty Endraswari, S.Pd', '10052014', 'Guru', 'XII', '118', 103),
(1006, 'Niko Arimba S.Pd', '10062016', 'Guru', 'XII', '118', 106),
(1007, 'Roso Arisdiyono, S.Pd', '10072012', 'Guru', 'XII', '118', 107),
(1008, 'Esti Wahyuni, S.Pd', '10082008', 'Guru', 'XII', '118', 108),
(1009, 'Mariana Listriyanti, S.E', '10092008', 'Guru', 'XII', '121', 109),
(1010, 'Lucia Puji Wardani, S.Pd', '10102012', 'Guru', 'XII', '118', 110),
(1011, 'Tessalonika D.M, S.Pd', '10112012', 'Guru', 'XII', '118', 111),
(1012, 'Agnes Evira, MM', '10122005', 'Guru', 'XII', '118', 112),
(1013, 'Apoloos Ryan Wibowo, S.Pd', '10132003', 'Guru', 'XII', '119', 1141),
(1014, 'Ita Indriastuti, S.Pd', '10142003', 'Guru', 'XII', '119', 1142),
(1015, 'Febri Setiyarto Nugroho, S.E', '10152005', 'Guru', 'XII', '121', 1151),
(1016, 'Mariana Listriyanti, S.E', '10092008', 'Guru', 'XII', '121', 1152);

-- --------------------------------------------------------

--
-- Table structure for table `tahun_ajaran`
--

CREATE TABLE IF NOT EXISTS `tahun_ajaran` (
  `id_ta` int(11) NOT NULL,
  `kd_ta` varchar(10) DEFAULT NULL,
  `tahun_ajaran` varchar(11) DEFAULT NULL,
  `semester` varchar(10) NOT NULL,
  `ket` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20163 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tahun_ajaran`
--

INSERT INTO `tahun_ajaran` (`id_ta`, `kd_ta`, `tahun_ajaran`, `semester`, `ket`) VALUES
(20161, '2016-1', '2016-2017', 'Ganjil', 'SEMESTER GANJIL TAHUN AJARAN 2016-2017'),
(20162, '2016-2', '2016-2017', 'Genap', 'SEMESTER GENAP TAHUN AJARAN 2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(20) NOT NULL,
  `id_pegawai` int(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` enum('1','2','3') NOT NULL,
  `nama_level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `id_pegawai`, `password`, `level`, `nama_level`) VALUES
('admin', 1111, 'admin', '1', 'admin'),
('G001', 1001, '1001', '2', 'Guru'),
('G002', 1002, '1002', '2', 'Guru'),
('G003', 1003, '1003', '2', 'Guru'),
('G004', 1004, '1004', '2', 'Guru'),
('G005', 1005, '1005', '2', 'Guru'),
('W001', 1001, '1001', '3', 'Walikelas'),
('W004', 1004, '1004', '3', 'Walikelas'),
('W009', 1009, '1009', '3', 'Walikelas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`), ADD KEY `id_jurusan` (`id_jurusan`), ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`id_mapel`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id_nilai`), ADD KEY `id_ta` (`id_ta`), ADD KEY `id_ta_id_kelas_id_mapel_id_siswa` (`id_kelas`,`sakit`,`id_siswa`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`), ADD KEY `id_mapel` (`id_mapel`);

--
-- Indexes for table `tahun_ajaran`
--
ALTER TABLE `tahun_ajaran`
  ADD PRIMARY KEY (`id_ta`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`), ADD KEY `id_pegawai` (`id_pegawai`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id_jurusan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=122;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12122;
--
-- AUTO_INCREMENT for table `mapel`
--
ALTER TABLE `mapel`
  MODIFY `id_mapel` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1154;
--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id_nilai` int(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1017;
--
-- AUTO_INCREMENT for table `tahun_ajaran`
--
ALTER TABLE `tahun_ajaran`
  MODIFY `id_ta` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20163;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `nilai`
--
ALTER TABLE `nilai`
ADD CONSTRAINT `nilai_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
