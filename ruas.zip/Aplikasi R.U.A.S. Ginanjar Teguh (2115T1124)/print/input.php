<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<title>CETAK RAPORT</title>
<h1>DAFTAR KELAS CETAK</h1>
</head>
<body align='center'>
<hr>
<table align="center">
<tr>
<td><button onclick="window.location.href='../login/walikelas.php'">BERANDA</button></td>
<td><button onclick="window.location.href='../login/logout.php'">KELUAR</button></td>
<tr>
</table>
<hr>
<?php
error_reporting(0);
ob_start();
// koneksi ke mysql
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");
?>

<form method="post" action="submit.php">
<table align="center">
<tr>
<td>KELAS</td>
<td><select name="kelas">

<?php
// query untuk menampilkan semua matakuliah dari tabel 'mk'
$query = "SELECT * FROM kelas";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  echo "<option value='".$data['id_kelas']."'>".$data['kode_kelas']."</option>";
}
?>
</select>
</td>
</tr>
<tr>
<td>SEMESTER</td>
<td><select name="TA">

<?php
// query untuk menampilkan semua matakuliah dari tabel 'mk'
$query = "SELECT * FROM tahun_ajaran";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  echo "<option value='".$data['id_ta']."'>".$data['semester']."</option>";
  
}
?>
</select>
</td>
</tr>
<tr>
<td></td>
<td>
<input type="submit" value="Submit" name="submit" />
</td>
</tr>
</table>
</form>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>  
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>