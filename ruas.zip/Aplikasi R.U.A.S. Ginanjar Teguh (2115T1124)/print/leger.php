<?php
if (isset($_GET['kelas']) AND isset($_GET['siswa'])){
$kls = $_GET['kelas'];
$NIS = $_GET['siswa'];
}
if (isset($_GET['mapel'])){
$KKM = $_GET['mapel']; 
}
?>
<html>
<head>
<title>LEGER WALIKELAS</title>
</head>
<body>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");


$query = "SELECT * FROM tahun_ajaran, kelas, nilai, mapel 
WHERE kelas.id_kelas = '$kls' AND nilai.id_kelas='$kls' AND nilai.id_siswa='$NIS'";

$hasil = mysql_query($query);
$data = mysql_fetch_array($hasil);

$nama		=$data['Nama'];
$nis1		=$data['id_siswa'];
$kelas		=$data['kode_kelas'];
$nm_kelas	=$data['nama_kelas'];
$th_ajar	=$data['ket'];
$semester	=$data['semester'];


$pknangka = $data['n101'];
    if ($pknangka)
    {
        $pknterbilang = ucwords(Terbilang($pknangka))." ";
		
    }
$pakangka = $data['n102'];
	if ($pakangka)
	{
		$pakterbilang = ucwords(Terbilang($pakangka))." ";
	}
$bindangka = $data['n103'];
	if ($bindangka)
	{
		$bindterbilang = ucwords(Terbilang($bindangka))." ";
	}
$bingangka = $data['n104'];
	if ($bingangka)
	{
		$bingterbilang = ucwords(Terbilang($bingangka))." ";
	}
$matangka = $data['n105'];
	if ($matangka)
	{
		$matterbilang = ucwords(Terbilang($matangka))." ";
	}	

$penjangka = $data['n106'];
	
	if ($penjangka)
	{
		$penjterbilang = ucwords(Terbilang($penjangka))." ";
	}	
	
$sbyangka = $data['n107'];
	if ($sbyangka)
	{
		$sbyterbilang = ucwords(Terbilang($sbyangka))." ";
	}
$ipsangka = $data['n108'];
	if ($ipsangka)
	{
		$ipsterbilang = ucwords(Terbilang($ipsangka))." ";
	}	
$kwuangka = $data['n109'];
	if ($kwuangka)
	{
		$kwuterbilang = ucwords(Terbilang($kwuangka))." ";
	}

$kkpiangka = $data['n110'];
	if ($kkpiangka)
	{
		$kkpiterbilang = ucwords(Terbilang($kkpiangka))." ";
	}

$bjaangka = $data['n111'];
	if ($bjaangka)
	{
		$bjaterbilang = ucwords(Terbilang($bjaangka))." ";
	}

$ipaangka = $data['n112'];
	if ($ipaangka)
	{
		$ipaterbilang = ucwords(Terbilang($ipaangka))." ";
	}	

$prod1angka = $data['n113'];
	if ($prod1angka)
	{
		$prod1terbilang = ucwords(Terbilang($prod1angka))." ";
	}	

$prod2angka = $data['n114'];
	if ($prod2angka)
	{
		$prod2terbilang = ucwords(Terbilang($prod2angka))." ";
	}	

$prod3angka = $data['n115'];
	if ($prod3angka)
	{
		$prod3terbilang = ucwords(Terbilang($prod3angka))." ";
	}	

$prod4angka = $data['n116'];
	if ($prod4angka)
	{
		$prod4terbilang = ucwords(Terbilang($prod4angka))." ";
	}	

$prod5angka = $data['n117'];
	if ($prod5angka)
	{
		$prod5terbilang = ucwords(Terbilang($prod5angka))." ";
	}	

$prod6angka = $data['n111'];
	if ($prod6angka)
	{
		$prod6terbilang = ucwords(Terbilang($prod6angka))." ";
	}		

    function Terbilang($x)
    {
        $ambil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
        if ($x < 12)
            return " " . $ambil[$x];
        elseif ($x < 20)
            return Terbilang($x - 10) . " belas";
        elseif ($x < 100)
            return Terbilang($x / 10) . " puluh" . Terbilang($x % 10);
        elseif ($x < 200)
            return " seratus" . Terbilang($x - 100);
        elseif ($x < 1000)
            return Terbilang($x / 100) . " ratus" . Terbilang($x % 100);
        elseif ($x < 2000)
            return " seribu" . Terbilang($x - 1000);
        elseif ($x < 1000000)
            return Terbilang($x / 1000) . " ribu" . Terbilang($x % 1000);
        elseif ($x < 1000000000)
            return Terbilang($x / 1000000) . " juta" . Terbilang($x % 1000000);
    }
$pkn		=$data['n101'];
if (($pkn >= 80) && ($pkn <= 100))
{$pknhuruf = 'A';}
else if (($pkn >= 70) && ($pkn <= 79))
{$pknhuruf = 'B';}
else if (($pkn >= 60) && ($pkn <= 69))
{$pknhuruf = 'C';}
else if (($pkn >= 50) && ($pkn <= 59))
{$pknhuruf = 'D';}
else if (($pkn >= 0) && ($pkn <= 49))
{$pknhuruf = 'E';}
$pknhuruf;


 
$pak		=$data['n102'];
if (($pak >= 80) && ($pak <= 100))
{$pakhuruf = 'A';}
else if (($pak >= 70) && ($pak <= 79))
{$pakhuruf = 'B';}
else if (($pak >= 60) && ($pak <= 69))
{$pakhuruf = 'C';}
else if (($pak >= 50) && ($pak <= 59))
{$pakhuruf = 'D';}
else if (($pak >= 0) && ($pak <= 49))
{$pakhuruf = 'E';}
 
$pakhuruf;

$bind		=$data['n103'];
if (($bind >= 80) && ($bind<= 100))
{$bindhuruf = 'A';}
else if (($bind	 >= 70) && ($bind <= 79))
{$bindhuruf = 'B';}
else if (($bind	 >= 60) && ($bind <= 69))
{$bindhuruf = 'C';}
else if (($bind	 >= 50) && ($bind <= 59))
{$bindhuruf = 'D';}
else if (($bind	 >= 0) && ($bind <= 49))
{$bindhuruf = 'E';}
 
$bindhuruf;

$bing		=$data['n104'];
if (($bing >= 80) && ($bing<= 100))
{$binghuruf = 'A';}
else if (($bing	 >= 70) && ($bing <= 79))
{$binghuruf = 'B';}
else if (($bing	 >= 60) && ($bing <= 69))
{$binghuruf = 'C';}
else if (($bing	 >= 50) && ($bing <= 59))
{$binghuruf = 'D';}
else if (($bing	 >= 0) && ($bing <= 49))
{$binghuruf = 'E';}
 
$binghuruf;

$mat		=$data['n105'];
if (($mat >= 80) && ($mat<= 100))
{$mathuruf = 'A';}
else if (($mat	 >= 70) && ($mat <= 79))
{$mathuruf = 'B';}
else if (($mat	 >= 60) && ($mat <= 69))
{$mathuruf = 'C';}
else if (($mat	 >= 50) && ($mat <= 59))
{$mathuruf = 'D';}
else if (($mat	 >= 0) && ($mat <= 49))
{$mathuruf = 'E';}
 
$mathuruf;

$penj		=$data['n106'];
if (($penj >= 80) && ($penj<= 100))
{$penjhuruf = 'A';}
else if (($penj	 >= 70) && ($penj <= 79))
{$penjhuruf = 'B';}
else if (($penj	 >= 60) && ($penj <= 69))
{$penjhuruf = 'C';}
else if (($penj	 >= 50) && ($penj <= 59))
{$penjhuruf = 'D';}
else if (($penj	 >= 0) && ($penj <= 49))
{$penjhuruf = 'E';}
 
$penjhuruf;

$sby		=$data['n107'];
if (($sby >= 80) && ($sby<= 100))
{$sbyhuruf = 'A';}
else if (($sby	 >= 70) && ($sby <= 79))
{$sbyhuruf = 'B';}
else if (($sby	 >= 60) && ($sby <= 69))
{$sbyhuruf = 'C';}
else if (($sby	 >= 50) && ($sby <= 59))
{$sbyhuruf = 'D';}
else if (($sby	 >= 0) && ($sby <= 49))
{$sbyhuruf = 'E';}
 
$sbyhuruf;

$ips		=$data['n108'];
if (($ips >= 80) && ($ips<= 100))
{$ipshuruf = 'A';}
else if (($ips	 >= 70) && ($ips <= 79))
{$ipshuruf = 'B';}
else if (($ips	 >= 60) && ($ips <= 69))
{$ipshuruf = 'C';}
else if (($ips	 >= 50) && ($ips <= 59))
{$ipshuruf = 'D';}
else if (($ips	 >= 0) && ($ips <= 49))
{$ipshuruf = 'E';}
 
$ipshuruf;

$kwu		=$data['n109'];
if (($kwu >= 80) && ($kwu<= 100))
{$kwuhuruf = 'A';}
else if (($kwu	 >= 70) && ($kwu <= 79))
{$kwuhuruf = 'B';}
else if (($kwu	 >= 60) && ($kwu <= 69))
{$kwuhuruf = 'C';}
else if (($kwu	 >= 50) && ($kwu <= 59))
{$kwuhuruf = 'D';}
else if (($kwu	 >= 0) && ($kwu <= 49))
{$kwuhuruf = 'E';}
 
$kwuhuruf;

$kkpi		=$data['n110'];
if (($kkpi >= 80) && ($kkpi<= 100))
{$kkpihuruf = 'A';}
else if (($kkpi	 >= 70) && ($kkpi <= 79))
{$kkpihuruf = 'B';}
else if (($kkpi	 >= 60) && ($kkpi <= 69))
{$kkpihuruf = 'C';}
else if (($kkpi	 >= 50) && ($kkpi <= 59))
{$kkpihuruf = 'D';}
else if (($kkpi	 >= 0) && ($kkpi <= 49))
{$kkpihuruf = 'E';}
 
$kkpihuruf;

$bja		=$data['n111'];
if (($bja >= 80) && ($bja<= 100))
{$bjahuruf = 'A';}
else if (($bja	 >= 70) && ($bja <= 79))
{$bjahuruf = 'B';}
else if (($bja	 >= 60) && ($bja <= 69))
{$bjahuruf = 'C';}
else if (($bja	 >= 50) && ($bja <= 59))
{$bjahuruf = 'D';}
else if (($bja	 >= 0) && ($bja <= 49))
{$bjahuruf = 'E';}
 
$bjahuruf;

$ipa		=$data['n112'];
if (($ipa >= 80) && ($ipa<= 100))
{$ipahuruf = 'A';}
else if (($ipa	 >= 70) && ($ipa <= 79))
{$ipahuruf = 'B';}
else if (($ipa	 >= 60) && ($ipa <= 69))
{$ipahuruf = 'C';}
else if (($ipa	 >= 50) && ($ipa <= 59))
{$ipahuruf = 'D';}
else if (($ipa	 >= 0) && ($ipa <= 49))
{$ipahuruf = 'E';}
 
$ipahuruf;

$prod1		=$data['n113'];
if (($prod1 >= 80) && ($prod1<= 100))
{$prod1huruf = 'A';}
else if (($prod1	 >= 70) && ($prod1 <= 79))
{$prod1huruf = 'B';}
else if (($prod1	 >= 60) && ($prod1 <= 69))
{$prod1huruf = 'C';}
else if (($prod1	 >= 50) && ($prod1 <= 59))
{$prod1huruf = 'D';}
else if (($prod1	 >= 0) && ($prod1 <= 49))
{$prod1huruf = 'E';}
 
$prod1huruf;

$prod2		=$data['n114'];
if (($prod2 >= 80) && ($prod2<= 100))
{$prod2huruf = 'A';}
else if (($prod2	 >= 70) && ($prod2 <= 79))
{$prod2huruf = 'B';}
else if (($prod2	 >= 60) && ($prod2 <= 69))
{$prod2huruf = 'C';}
else if (($prod2	 >= 50) && ($prod2 <= 59))
{$prod2huruf = 'D';}
else if (($prod2	 >= 0) && ($prod2 <= 49))
{$prod2huruf = 'E';}
 
$prod2huruf;

$prod3		=$data['n115'];
if (($prod3 >= 80) && ($prod3<= 100))
{$prod3huruf = 'A';}
else if (($prod3	 >= 70) && ($prod3 <= 79))
{$prod3huruf = 'B';}
else if (($prod3	 >= 60) && ($prod3 <= 69))
{$prod3huruf = 'C';}
else if (($prod3	 >= 50) && ($prod3 <= 59))
{$prod3huruf = 'D';}
else if (($prod3	 >= 0) && ($prod3 <= 49))
{$prod3huruf = 'E';}
 
$prod3huruf;

$prod4		=$data['n116'];
if (($prod4 >= 80) && ($prod4<= 100))
{$prod4huruf = 'A';}
else if (($prod4	 >= 70) && ($prod4 <= 79))
{$prod4huruf = 'B';}
else if (($prod4	 >= 60) && ($prod4 <= 69))
{$prod4huruf = 'C';}
else if (($prod4	 >= 50) && ($prod4 <= 59))
{$prod4huruf = 'D';}
else if (($prod4	 >= 0) && ($prod4 <= 49))
{$prod4huruf = 'E';}
 
$prod4huruf;

$prod5		=$data['n117'];
if (($prod5 >= 80) && ($prod5<= 100))
{$prod5huruf = 'A';}
else if (($prod5	 >= 70) && ($prod5 <= 79))
{$prod5huruf = 'B';}
else if (($prod5	 >= 60) && ($prod5 <= 69))
{$prod5huruf = 'C';}
else if (($prod5	 >= 50) && ($prod5 <= 59))
{$prod5huruf = 'D';}
else if (($prod5	 >= 0) && ($prod5 <= 49))
{$prod5huruf = 'E';}
 
$prod5huruf;

$prod6		=$data['n118'];
if (($prod6 >= 80) && ($prod6<= 100))
{$prod6huruf = 'A';}
else if (($prod6	 >= 70) && ($prod6 <= 79))
{$prod6huruf = 'B';}
else if (($prod6	 >= 60) && ($prod6 <= 69))
{$prod6huruf = 'C';}
else if (($prod6	 >= 50) && ($prod6 <= 59))
{$prod6huruf = 'D';}
else if (($prod6	 >= 0) && ($prod6 <= 49))
{$prod6huruf = 'E';}
 
$prod6huruf;

$jumlah=$pkn+$pak+$bind+$bing+$mat+$penj+$sby+$ips+$kwu+$kkpi+$bja+$ipa+$prod1+$prod2+$prod3+$prod4+$prod5+$prod6;
$rata=($pkn+$pak+$bind+$bing+$mat+$penj+$sby+$ips+$kwu+$kkpi+$bja+$ipa+$prod1+$prod2+$prod3+$prod4+$prod5+$prod6)/18;
$hrata = number_format($rata,2);

$query1 = "SELECT * FROM nilai WHERE id_siswa='$NIS'";
$hasil1 = mysql_query($query1);
$data1 = mysql_fetch_array($hasil1);
$ijin		=$data1['ijin'];
$sakit		=$data1['sakit'];
$alpha		=$data1['alpha'];
$kelakuan	=$data1['kelakuan'];
$kerajinan	=$data1['kerajinan'];
$kerapian	=$data1['kerapian'];
 
echo" 
<table width='945 height='43' border='0'>
  <tr>
    <td width='935' height='37'><div align='center'><span class='style8'><strong>LAPORAN AKHIR HASIL BELAJAR</strong></span></div></td>
  </tr>
  <tr>
	<td><div align='center'><strong>$th_ajar</strong></td>
  </tr>
</table>
<p>&nbsp;</p>

<table width='938' border='0'>
  <tr>

  <td width='180'><span class='style2'>Nama</span></td>
    <td width='343'><span class='style2'>: $nama</span></td>
    <td width='209'><span class='style2'>Kelas</span></td>
    <td width='188'>: 	$kelas</td>
  </tr>
  <tr>
    <td><span class='style2'>NIS</span></td>
    <td><span class='style2'>: $nis1</span></td>
    <td><span class='style2'>Semester</span></td>
    <td><span class='style2'>: $semester </span></td>
  </tr>
  <tr>
    <td><span class='style2'>Bidang Keahlian</span></td>
    <td><span class='style2'>: Bisnis Manajemen</span></td>
    <td><span class='style2'>Kompetensi </span></td>
    <td><span class='style2'>: $nm_kelas</span></td>
  </tr>
  <tr>
    <td><span class='style2'></span></td>
    <td><span class='style2'></span></td>
    <td><span class='style2'> </span></td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>

<table width='943' border='1'>
  <tr bgcolor='#666666'>
    <td width='38' rowspan='2'><div align='center' class='style5'>No</div></td>
    <td width='293' rowspan='2'><div align='center' class='style5'>Mata Pelajaran</div></td>
    <td width='58' rowspan='2'><div align='center' class='style5'>KKM</div></td>
    <td colspan='2'><div align='center' class='style5'>Nilai</div></td>
    <td width='155' rowspan='2'><div align='center' class='style5'>Predikat</div></td>
  </tr>
  <tr>
    <td width='113' bgcolor='#666666'><div align='center' class='style5'>Angka</div></td>
    <td width='246' bgcolor='#666666'><div align='center' class='style5'>Huruf</div></td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td colspan='6'><span class='style2'>I. NORMATIF</span></td>
  </tr>
  <tr>
    <td><div align='center'><span class='style2'>1</span></div></td>
    <td><div align='left'><span class='style2'>Pendidikan Kewarganegaraan</span></div></td>";
    
$tampilpkn = "SELECT * FROM mapel WHERE id_mapel='101'";
$tampilpkn2 = mysql_query($tampilpkn);
$kkmpkn  = mysql_fetch_array($tampilpkn2);
$tampilpkn=$kkmpkn['kkm'];

echo"	
	<td align='center'>$tampilpkn</td>
    <td align='center'>$pkn</td>
    <td>$pknterbilang</td>
    <td align='center'>$pknhuruf</td>
  </tr>
  <tr>
    <td><div align='center'><span class='style2'>2</span></div></td>
    <td><div align='left'><span class='style2'></span>Pendidikan Agama</div></td>
	";
 
$tampilagm = "SELECT * FROM mapel WHERE id_mapel='102'";
$tampilagm2 = mysql_query($tampilagm);
$kkmagm  = mysql_fetch_array($tampilagm2);
$tampilagm=$kkmagm['kkm'];

echo"    
    <td align='center'>$tampilagm</td>
    <td align='center'>$pak</td>
    <td>$pakterbilang</td>
    <td align='center'>$pakhuruf</td>
  </tr>
  <tr>
    <td><div align='center'><span class='style2'>3</span></div></td>
    <td><div align='left'><span class='style2'>Bahasa Indonesia</span></div></td>";
 
$tampilbind = "SELECT * FROM mapel WHERE id_mapel='103'";
$tampilbind2 = mysql_query($tampilbind);
$kkmbind  = mysql_fetch_array($tampilbind2);
$tampilbind=$kkmbind['kkm'];

echo"    
	<td align='center'>$tampilbind</td>
    <td align='center'>$bind</td>
    <td>$bindterbilang</td>
    <td align='center'>$bindhuruf</td>
  </tr>
  <tr>
    <td><div align='center'><span class='style2'>4</span></div></td>
    <td><div align='left'><span class='style2'>Pendidikan Jasmani Kesehatan</span></div></td>";

$tampilpenj  = "SELECT * FROM mapel WHERE id_mapel='106'";
$tampilpenj2 = mysql_query($tampilpenj);
$kkmpenj     = mysql_fetch_array($tampilpenj2);
$tampilpenj  =$kkmpenj['kkm'];

echo"     
	
	<td align='center'>$tampilpenj</td>
    <td align='center'>$penj</td>
    <td>$penjterbilang</td>
    <td align='center'>$penjhuruf</td>
  </tr>
  <tr>
    <td><div align='center'><span class='style2'>5</span></div></td>
    <td><div align='left'><span class='style2'>Seni Budaya</span></div></td>";

$tampilsby  = "SELECT * FROM mapel WHERE id_mapel='107'";
$tampilsby2 = mysql_query($tampilsby);
$kkmsby     = mysql_fetch_array($tampilsby2);
$tampilsby  =$kkmsby['kkm'];

echo"     
    <td align='center'>$tampilsby</td>
    <td align='center'>$sby</td>
    <td>$sbyterbilang </td>
    <td align='center'>$sbyhuruf</td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td colspan='6'><span class='style2'>II. ADAPTIF</span></td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>1</div></td>
    <td><span class='style2'>Matematika</span></td>";

$tampilmat  = "SELECT * FROM mapel WHERE id_mapel='105'";
$tampilmat2 = mysql_query($tampilmat);
$kkmmat     = mysql_fetch_array($tampilmat2);
$tampilmat  =$kkmmat['kkm'];

echo"  
    <td align='center'>$tampilmat</td>
    <td align='center'>$mat</td>
    <td>$matterbilang</td>
    <td align='center'>$mathuruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>2</div></td>
    <td><span class='style2'>Bahasa Inggris</span></td>";

$tampilbing  = "SELECT * FROM mapel WHERE id_mapel='104'";
$tampilbing2 = mysql_query($tampilbing);
$kkmbing     = mysql_fetch_array($tampilbing2);
$tampilbing  =$kkmbing['kkm'];

echo"  
    <td align='center'>$tampilbing</td>
    <td align='center'>$bing</td>
    <td>$bingterbilang</td>
    <td align='center'>$binghuruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>3</div></td>
    <td><span class='style2'>Ilmu Pengetahuan Sosial</span></td>";

$tampilips  = "SELECT * FROM mapel WHERE id_mapel='108'";
$tampilips2 = mysql_query($tampilips);
$kkmips     = mysql_fetch_array($tampilips2);
$tampilips  =$kkmips['kkm'];

echo"  
    <td align='center'>$tampilips</td>
    <td align='center'>$ips</td>
    <td>$ipsterbilang</td>
    <td align='center'>$ipshuruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>4</div></td>
    <td><span class='style2'>Ilmu Pengetahuan Alam</span></td>";

$tampilipa  = "SELECT * FROM mapel WHERE id_mapel='112'";
$tampilipa2 = mysql_query($tampilipa);
$kkmipa     = mysql_fetch_array($tampilipa2);
$tampilipa  =$kkmipa['kkm'];

echo" 
    <td align='center'>$tampilipa</td>
    <td align='center'>$ipa</td>
    <td>$ipaterbilang</td>
    <td align='center'>$ipahuruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>5</div></td>
    <td><span class='style2'>KKPI</span></td>";

$tampilkkpi  = "SELECT * FROM mapel WHERE id_mapel='112'";
$tampilkkpi2 = mysql_query($tampilkkpi);
$kkmkkpi     = mysql_fetch_array($tampilkkpi2);
$tampilkkpi  =$kkmkkpi['kkm'];

echo" 
    <td align='center'>$tampilkkpi</td>
    <td align='center'>$kkpi</td>
    <td>$kkpiterbilang</td>
    <td align='center'>$kkpihuruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>6</div></td>
    <td><span class='style2'>Kewirausahaan</span></td>";

$tampilkwu  = "SELECT * FROM mapel WHERE id_mapel='109'";
$tampilkwu2 = mysql_query($tampilkwu);
$kkmkwu     = mysql_fetch_array($tampilkwu2);
$tampilkwu  =$kkmkwu['kkm'];

echo" 
    <td align='center'>$tampilkwu</td>
    <td align='center'>$kwu</td>
    <td>$kwuterbilang</td>
    <td align='center'>$kwuhuruf</td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td colspan='6'><span class='style2'>III. PRODUKTIF</span></td>
  </tr>
  <tr>
    <td colspan='2'><span class='style2'>Kompetensi Dasar</span></td>
    <td></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>1</div></td>
    <td><span class='style2'>Produktif 1</span></td>";

$tampilprod1  = "SELECT * FROM mapel WHERE id_mapel='1131'";
$tampilprod12 = mysql_query($tampilprod1);
$kkmprod1     = mysql_fetch_array($tampilprod12);
$tampilprod1  =$kkmprod1['kkm'];

echo"
    <td align='center'>$tampilprod1</td>
    <td align='center'>$prod1</td>
    <td>$prod1terbilang</td>
    <td align='center'>$prod1huruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>2</div></td>
    <td><span class='style2'>Produktif 2</span></td>";

$tampilprod2  = "SELECT * FROM mapel WHERE id_mapel='1132'";
$tampilprod22 = mysql_query($tampilprod2);
$kkmprod2     = mysql_fetch_array($tampilprod22);
$tampilprod2  =$kkmprod2['kkm'];

echo"
    <td align='center'>$tampilprod2</td>
    <td align='center'>$prod2</td>
    <td>$prod2terbilang</td>
    <td align='center'>$prod2huruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>3</div></td>
    <td><span class='style2'>Produktif 3</span></td>";

$tampilprod3  = "SELECT * FROM mapel WHERE id_mapel='1133'";
$tampilprod32 = mysql_query($tampilprod3);
$kkmprod3     = mysql_fetch_array($tampilprod32);
$tampilprod3  =$kkmprod3['kkm'];

echo"
    <td align='center'>$tampilprod3</td>
    <td align='center'>$prod3</td>
    <td>$prod3terbilang</td>
    <td align='center'>$prod3huruf</td>
  </tr>
  <tr>
    <td colspan='2'><span class='style2'>Kompetensi Kejuruan</span></td>
    <td></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>1</div></td>
    <td><span class='style2'>Produktif 4</span></td>";

$tampilprod4  = "SELECT * FROM mapel WHERE id_mapel='1141'";
$tampilprod42 = mysql_query($tampilprod4);
$kkmprod4     = mysql_fetch_array($tampilprod42);
$tampilprod4  =$kkmprod4['kkm'];

echo"
    <td align='center'>$tampilprod4</td>
    <td align='center'>$prod4</td>
    <td>$prod4terbilang</td>
    <td align='center'>$prod4huruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>2</div></td>
    <td><span class='style2'>Produktif 5</span></td>";

$tampilprod5  = "SELECT * FROM mapel WHERE id_mapel='1142'";
$tampilprod52 = mysql_query($tampilprod5);
$kkmprod5     = mysql_fetch_array($tampilprod52);
$tampilprod5  =$kkmprod5['kkm'];

echo"
    <td align='center'>$tampilprod5</td>
    <td align='center'>$prod5</td>
    <td>$prod5terbilang</td>
    <td align='center'>$prod5huruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>3</div></td>
    <td><span class='style2'>Produktif 6</span></td>";

$tampilprod6  = "SELECT * FROM mapel WHERE id_mapel='1143'";
$tampilprod62 = mysql_query($tampilprod6);
$kkmprod6     = mysql_fetch_array($tampilprod62);
$tampilprod6  =$kkmprod6['kkm'];

echo"
    <td align='center'>$tampilprod6</td>
    <td align='center'>$prod6</td>
    <td>$prod6terbilang</td>
    <td align='center'>$prod6huruf</td>
  </tr>
  <tr>
    <td><span class='style2'></span></td>
    <td><span class='style2'></span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan='6' bgcolor='#CCCCCC'><span class='style2'>IV. MUATAN LOKAL</span></td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>1</div></td>
    <td><span class='style2'>Bahasa Jawa</span></td>";

$tampilbjaw  = "SELECT * FROM mapel WHERE id_mapel='111'";
$tampilbjaw  = mysql_query($tampilbjaw);
$kkmbjaw     = mysql_fetch_array($tampilbjaw);
$tampilbjaw  = $kkmbjaw['kkm'];

echo"
    <td align='center'>$tampilbjaw</td>
    <td align='center'>$bja</td>
    <td>$bjaterbilang</td>
    <td align='center'>$bjahuruf</td>
  </tr>
  <tr>
    <td><div align='center' class='style2'>2</div></td>
    <td><span class='style2'></span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan='3'><div align='center'><span class='style1'>Jumlah</span></div></td>
    <td align='center'>$jumlah</td>
    <td colspan='2'>&nbsp;</td>
  </tr>
  <tr>
    <td colspan='3'><div align='center'><span class='style1'>Rata-rata</span></div></td>
    <td align='center'>$hrata</td>
    <td colspan='2'>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table width='945' height='43' border='0'>
  <tr>
    <td width='935' height='37'><div align='center'><span class='style8'>CATATAN AKHIR SEMESTER</span></div></td>
  </tr>
</table>
<p align='center' class='style1'>&nbsp;</p>
<p align='left' class='style1'>I. KEPRIBADIAN</p>
<table width='945' border='1'>
  <tr>
    <td width='42' bgcolor='#999999'><div align='center' class='style6'><span class='style1'>No</span></div></td>
    <td width='471' bgcolor='#999999'><div align='center' class='style6'><span class='style1'>Aspek</span></div></td>
    <td width='410' bgcolor='#999999'><div align='center' class='style6'><span class='style1'>Keterangan</span></div></td>
  </tr>
  <tr>
    <td><span class='style2'>1</span></td>
    <td><span class='style2'>Kelakuan</span></td>
    <td align='center'><span class='style2'>$kelakuan</span></td>
  </tr>
  <tr>
    <td><span class='style2'>2</span></td>
    <td><span class='style2'>Kerajinan</span></td>
    <td align='center'><span class='style2'>$kerajinan</span></td>
  </tr>
  <tr>
    <td><span class='style2'>3</span></td>
    <td><span class='style2'>Kerapian</span></td>
    <td align='center'><span class='style2'>$kerapian</span></td>
  </tr>
</table>
<p align='left' class='style1'>&nbsp;</p>
<p align='left' class='style1'>II. KEHADIRAN</p>
<table width='945' border='1'>
  <tr>
    <td width='42' bgcolor='#999999'><div align='center' class='style6'><span class='style1'>No</span></div></td>
    <td width='471' bgcolor='#999999'><div align='center' class='style6'><span class='style1'>Aspek</span></div></td>
    <td width='410' bgcolor='#999999'><div align='center' class='style6'><span class='style1'>Keterangan</span></div></td>
  </tr>
  <tr>
    <td><span class='style2'>1</span></td>
    <td><span class='style2'>Sakit</span></td>
    <td align='center'><span class='style2'>$sakit</span></td>
  </tr>
  <tr>
    <td><span class='style2'>2</span></td>
    <td><span class='style2'>Ijin</span></td>
    <td align='center'><span class='style2'>$ijin</span></td>
  </tr>
  <tr>
    <td><span class='style2'>3</span></td>
    <td><span class='style2'>Tanpa Keterangan</span></td>
    <td align='center'><span class='style2'>$alpha</span></td>
  </tr>
</table>
<p align='left' class='style1'>&nbsp;</p>
<p align='left' class='style1'>III. CATATAN dan INFORMASI</p>
<table width='945' height='81' border='1'>
  <tr>";
    if($alpha > 20)
  {
	  $keterangan="Kami mohon perhatian dan dukungan Orang Tua/Siswa untuk membantu 
	  Kedisiplinan Siswa dengan mengisikan No HP Orang Tua/Wali dibawah ini sebagai sarana pemantauan ABSENSI Siswa";
  }elseif($semester)
  {
	  $keterangan=" ";
  }
  echo"
    <td width='935'><font color='red'><strong>$keterangan</strong></font></td>
  </tr>
</table>
<p align='left' class='style1'>&nbsp;</p>
<table width='943' border='0'>
  <tr>
    <td width='506'>&nbsp;</td>
    <td width='427'><span class='style2'>Diberikan di : SMK Kristen Purwodadi </span></td>
  </tr>
  <tr>
    <td></td>
    <td><span class='style2'>Tanggal : </span></td>
  </tr>
  <tr>
    <td class='style2'>Walikelas</td>";
	$semester = $semester['ganjil'];
	if ($semester)
	{
		$naik =" ";
	}elseif ($semester)
	{
		$naik="Dengan memperhatikan hasil dari Semester Ganjil dan Genap maka siswa tersebut dinyatakan NAIK/TIDAK NAIK";
	}
    echo"<td>$naik</td>
  </tr>
  <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>";

$qwali      = "SELECT nama_guru FROM pegawai, kelas WHERE pegawai.id_pegawai=kelas.id_pegawai AND kelas.id_kelas='$kls'";
$qhasil		= mysql_query($qwali);
$wal	    = mysql_fetch_array($qhasil);

$tampilwali=$wal['nama_guru'];
		
echo"
    <td><strong>$tampilwali</strong></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class='style2'>Mengetahui, </span></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class='style2'>Orang tua/Wali</span></td>
    <td><span class='style2'>Kepala SMK Kristen Purwodadi</span></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td>..........................................</td>
    <td><strong>Ita Indriastuti, S.Pd</strong></td>
  </tr>
</table>
";
?>
<p align="left" class="style1">&nbsp;</p>
	<script>
		window.load = print_d();
		function print_d(){
			window.print();
		}
	</script>
</body>
</html>
