<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<br>
<title>DAFTAR CETAK NILAI</title>
<h1>FORM CETAK NILAI</h1>
</head>
<body align='center'>
<hr>
<table align="center">
<tr>
<td><button onclick="window.location.href='../login/walikelas.php'">BERANDA</button></td>
<td><button onclick="window.location.href='input.php'">KEMBALI</button></td>
<td><button onclick="window.location.href='../login/logout.php'">KELUAR</button></td>
<tr>
</table>
<hr>
<div style="border:1px solidgrey; width:1336px;height:400px;overflow-y:scroll;overflow-x:hidden;">
<table border="1" align='center' class="table1">
<tr><th>NO</th><th>NIS</th><th>NAMA</th><th>KELAS</th><th>SEMESTER</th><th>OPSI</th></tr>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");

// membaca kode matakuliah yang disubmit dari formnilai.php
$kelasName	= $_POST['kelas'];
$TA	        = $_POST['TA'];

// menampilkan data nim dan nilai mahasiswa yang mengambil matakuliah berdasarkan kode MK

$query = "SELECT tahun_ajaran.id_ta, tahun_ajaran.semester, kelas.id_kelas, kelas.kode_kelas, nilai.id_siswa, nilai.id_nilai, nilai.nama
FROM kelas, nilai, tahun_ajaran 
WHERE kelas.id_kelas = '$kelasName' AND nilai.id_kelas='$kelasName' AND tahun_ajaran.id_ta='$TA'";

$hasil=MySQL_query ($query);    //fungsi untuk SQL


// nilai awal variabel untuk no urut
$i = 1;

// perintah untuk membaca dan mengambil data dalam bentuk array
while ($data = mysql_fetch_array ($hasil)){
$id = $data['id_nilai'];
 echo " 
  <tr>
  <td><center>".$i."</center></td> 
  <td>".$data['id_siswa']."</td>
  <td>".$data['nama']."</td>
  <td>".$data['kode_kelas']."</td>
  <td>".$data['semester']."</td>
  <td> 
  <form action = 'raport.php' method = 'GET' target='_blank' >
  
	<input type = 'hidden' name = 'kelas' value = '".$data['id_kelas']."'>
			<input type = 'hidden' name = 'siswa' value = '".$data['id_siswa']."'>
			<input type = 'hidden' name = 'mapel' value = '".$data['id_mapel']."'>
		
			<input type = 'submit' name = 'cetak' value = 'Cetak Raport'  ></input>
   
</form>
  </td>
  </tr> ";
 $i++; 
}
?>
<tr>
</tr>
</table>
	
</div>
<br/>
</form>
<br>  
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>