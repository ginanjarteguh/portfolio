<html>
<head>
<br>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<title>DATA MAPEL</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fid_mapel			= "";	
$fkd_mapel			= "";	
$fnama_mapel		= "";
$fkkm				= "";	

?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM mapel where id_mapel='$_GET[id_mapel]'");
$r		= mysql_fetch_array($tampil);
$ftitle			= "<h3 align='center'>UBAH DATA</h3>";	
$fid_mapel		= $r['id_mapel'];	
$fkd_mapel		= $r['kd_mapel'];	
$fnama_mapel	= $r['nama_mapel'];	
$fkkm			= $r['kkm'];	
}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>DATA MAPEL</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fid_mapel ?>">
	<?php } 	?>
	<table>
	
	<tr><td>ID MAPEL</td><td><input type="text" name="id_mapel" value="<?= $fid_mapel ?>"></td></tr>
	<tr><td>KODE MAPEL</td><td><input type="text" name="kd_mapel" value="<?= $fkd_mapel ?>"></td></tr>
	<tr><td>NAMA MAPEL</td><td><input type="text" name="nama_mapel" value="<?= $fnama_mapel ?>"></td></tr>
	<tr><td>KKM</td><td><input type="text" name="kkm" value="<?= $fkkm ?>"></td></tr>
	<tr><td colspan="2" align="center"><input type="submit" name="submit" 	value="INPUT"> <input  type="button" value="Cancel" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['id_mapel'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO mapel(id_mapel, kd_mapel, nama_mapel, kkm) VALUES ('$_POST[id_mapel]','$_POST[kd_mapel]','$_POST[nama_mapel]','$_POST[kkm]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE mapel SET id_mapel = '$_POST[id_mapel]',kd_mapel = '$_POST[kd_mapel]',nama_mapel = '$_POST[nama_mapel]', kkm = '$_POST[kkm]' WHERE id_mapel  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM mapel WHERE id_mapel='$_GET[id]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<center>
<h1>NAMA MATA PELAJARAN</h1>
<a href='<?= $_SERVER['PHP_SELF'] ?>'>Index</a> | <a href='?op=tambah'>Tambah </a> | <a href='login/admin.php'>Beranda</a><br><br>
</center>
<table width="70%" border="1" style="margin: 0 auto;">
<tr>
<th>No</th>
<th>ID MAPEL</th>
<th>KODE MAPEL</th>
<th>NAMA MAPEL</th>
<th>KKM</th>
<th>OPERASI</th>
</tr>

<?php
	$tampil=mysql_query("SELECT * FROM mapel ORDER BY id_mapel ASC"); // query sql
	$no=1;
	while ($r=mysql_fetch_array($tampil)){ 							//perulangan menampilkan data
	echo "
			<tr>
				<td>$no</td>
				<td>$r[id_mapel]</td>
				<td>$r[kd_mapel]</td>
				<td>$r[nama_mapel]</td>
				<td>$r[kkm]</td>
				<td>
				<a href='?op=edit&id_mapel=$r[id_mapel]'>Edit</a>
				<a href='?op=hapus&id_mapel=$r[id_mapel]'>Hapus</a>
				</td>
			</tr>
		";
	$no++;
	}
?>
</table>
</body>
</html>
