<html>
<title>
UPDATE NILAI SIKAP
</title>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<br>
</head>
<body>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");

// membaca jumlah mahasiswa (n) dari submit.php
$jumMhs = $_POST['n'];

// proses looping untuk membaca nilai dan nim mahasiswa dari form, serta menjalankan query update
for ($i=1; $i<=$jumMhs; $i++)
{
   // membaca nim mahasiswa ke-i, i = 1, 2, 3, ..., n
   $nis = $_POST['id_siswa'.$i];

   // membaca nilai mahasiswa ke-i, i = 1, 2, 3, ..., n
   $ijin      = $_POST['ijin'.$i];
   $sakit     = $_POST['sakit'.$i];
   $alpha 	  = $_POST['alpha'.$i];
   $kelakuan  = $_POST['kelakuan'.$i];
   $kerajinan = $_POST['kerajinan'.$i];
   $kerapian  = $_POST['kerapian'.$i];

   // update nilai mahasiswa ke-i, i = 1, 2, 3, ..., n
   $query = "UPDATE nilai SET ijin = '$ijin', sakit = '$sakit', alpha = '$alpha', kelakuan = '$kelakuan', kerajinan = '$kerajinan', kerapian = '$kerapian'  WHERE id_siswa = '$nis'";
   mysql_query($query);
//echo ",kelakuan=$kelakuan,kerajinan=$kerajinan,kerapian =$kerapian";
}
echo '<br><br><br><h1><strong>Nilai berhasil disimpan klik <a href="input.php">Disini</a> untuk melanjutkan</h1>

<br>
';
//header('location:input.php');

?>
</body>
</html>