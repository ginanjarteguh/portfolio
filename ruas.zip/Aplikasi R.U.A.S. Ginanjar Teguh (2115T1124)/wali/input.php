<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<title>NILAI SIKAP</title>
<h1>DAFTAR NILAI SIKAP</h1>
</head>
<body align='center'>
<br>
<hr>
<table align="center">
<tr>
<td><button onclick="window.location.href='../login/walikelas.php'">BERANDA</button></td>
<td><button onclick="window.location.href='../print/input.php'">CETAK</button></td>
<td><button onclick="window.location.href='../index.php'">KELUAR</button></td>
<tr>
</table>
<hr>
<?php
error_reporting(0);
ob_start();
// koneksi ke mysql
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");
?>
<table align="center">
<tr>
<form method="post" action="submit.php">
<td>
KELAS :
</td>
<td>
<select name="kelas">
<?php
// query untuk menampilkan semua matakuliah dari tabel 'mk'
$query = "SELECT * FROM kelas";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  echo "<option value='".$data['id_kelas']."'>".$data['kode_kelas']."</option>";
}
?>
<input type="submit" value="Submit" name="submit" />
</select>
</td>
</form>
</tr>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>  
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>