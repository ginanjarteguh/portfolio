<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<title>NILAI SIKAP</title>
<h1>INPUT NILAI SIKAP</h1>
</head>
<body align='center'>
<?php
error_reporting(0);
ob_start();
mysql_connect("localhost", "root", "");
mysql_select_db("nilai");
$kelasName	= $_POST['kelas'];
?>
<hr>
<table align="center">
<tr>
<td><button onClick="window.location.href='../login/walikelas.php'">BERANDA</button></td>
<td><button onClick="window.location.href='../wali/input.php'">KEMBALI</button></td>
<td><button onClick="window.location.href='../index.php'">KELUAR</button></td>
<tr>
</table>
<hr>
<form method="post" action="update.php">
<table border="0" align="center">
<tr>
			<?php
			$querykelas = "SELECT kode_kelas FROM kelas WHERE id_kelas='$kelasName'";
			$hasilkelas = mysql_query($querykelas);
			while ($datakelas = mysql_fetch_array($hasilkelas))
			{
			$NamaKelas = $datakelas['kode_kelas'];
			}
			?>
			<td>KELAS :</td><td><?php echo $NamaKelas;?></td>
</tr>
</table>
<div style="border:1px solidgrey; width:1336px;height:400px;overflow-y:scroll;overflow-x:hidden;">
<table width="62%" border="1" align='center' class="table1">
<tr><th width="7%">No</th>
<th width="8%">NIS</th>
<th width="10%">Nama</th>
<th width="7%">Ijin</th>
<th width="9%">Sakit</th>
<th width="10%">Alpha</th>
<th width="20%">Kelakuan</th>
<th width="20%">Kerajinan</th>
<th width="20%">Kerapian</th>
</tr>
<?php

// membaca kode matakuliah yang disubmit dari formnilai.php
// menampilkan data nim dan nilai mahasiswa yang mengambil matakuliah berdasarkan kode MK
$query = "SELECT id_siswa, Nama, ijin, sakit, alpha, kelakuan, kerajinan, kerapian FROM nilai WHERE id_kelas='$kelasName'";
$hasil = mysql_query($query);


// inisialisasi counter
$i = 1;
while ($data = mysql_fetch_array($hasil))
	
{
   echo "<tr>	
				<td width='7%'>".$i."</td>
				<td width='8%'><input type='hidden' name='id_siswa".$i."' value='".$data['id_siswa']."' />".$data['id_siswa']."</td>
				<td width='10%'>".$data['Nama']."</td>
				<td width='5%'><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='ijin".$i."' value='".$data['ijin']."' />
				</td>
				<td width='5%'><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='sakit".$i."' value='".$data['sakit']."' />
				</td>
				<td width='5%'><input type='hidden' name='siswa".$i."' value='".$data['id_siswa']."' />
					<input type='text' name='alpha".$i."' value='".$data['alpha']."' />
				</td>
				
				<td width='30%'>
				";
			if( $data['kelakuan'] == 'A') {	
				echo "<input type='radio' name='kelakuan".$i."' value='A' checked>A</input>
					<input type='radio' name='kelakuan".$i."' value='B' >B</input>
					<input type='radio' name='kelakuan".$i."' value='C' >C</input>";
			}elseif ( $data['kelakuan'] == 'B') {	
				echo "<input type='radio' name='kelakuan".$i."' value='A' >A</input>
					<input type='radio' name='kelakuan".$i."' value='B' checked>B</input>
					<input type='radio' name='kelakuan".$i."' value='C' >C</input>";
			}
			elseif ( $data['kelakuan'] == 'C') {	
				echo "<input type='radio' name='kelakuan".$i."' value='A' >A</input>
					<input type='radio' name='kelakuan".$i."' value='B' >B</input>
					<input type='radio' name='kelakuan".$i."' value='C' checked>C</input>";
			}
			echo "</td>";
			
				echo"<td>";
			if( $data['kerajinan'] == 'A') {	
				echo "
					<input type='radio' name='kerajinan".$i."' value='A' checked>A</input>
					<input type='radio' name='kerajinan".$i."' value='B' >B</input>
					<input type='radio' name='kerajinan".$i."' value='C' >C</input>";
			}elseif ( $data['kerajinan'] == 'B') {	
				echo "
					<input type='radio' name='kerajinan".$i."' value='A' >A</input>
					<input type='radio' name='kerajinan".$i."' value='B' checked>B</input>
					<input type='radio' name='kerajinan".$i."' value='C' >C</input>";
			}
			elseif ( $data['kerajinan'] == 'C') {	
				echo "
					<input type='radio' name='kerajinan".$i."' value='A' >A</input>
					<input type='radio' name='kerajinan".$i."' value='B' >B</input>
					<input type='radio' name='kerajinan".$i."' value='C' checked>C</input>";
			}
			echo "</td>";
			
			
				echo"<td>";
			if( $data['kerapian'] == 'A') {	
				echo "
					<input type='radio' name='kerapian".$i."' value='A' checked>A</input>
					<input type='radio' name='kerapian".$i."' value='B' >B</input>
					<input type='radio' name='kerapian".$i."' value='C' >C</input>";
			}elseif ( $data['kerapian'] == 'B') {	
				echo "
					<input type='radio' name='kerapian".$i."' value='A' >A</input>
					<input type='radio' name='kerapian".$i."' value='B' checked>B</input>
					<input type='radio' name='kerapian".$i."' value='C' >C</input>";
			}
			elseif ( $data['kerapian'] == 'C') {	
				echo "
					<input type='radio' name='kerapian".$i."' value='A' >A</input>
					<input type='radio' name='kerapian".$i."' value='B' >B</input>
					<input type='radio' name='kerapian".$i."' value='C' checked>C</input>";
			}
			echo "</td>";
				echo" 
						</tr>";
   $i++;
}
$jumMhs = $i-1;
?>
<tr>
<br>
</tr>
</table>
</div>
<table border="0" align="Center">
<tr>

			<td>
			<input type="submit" value="Simpan" name="submit"/>
			</td>
</tr>
</table>
<br>
<input type="hidden" name="n" value="<?php echo $jumMhs ?>" />
<input type="hidden" name="id_kelas" value="<?php echo $kelasName;?>">
</form>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>  
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>