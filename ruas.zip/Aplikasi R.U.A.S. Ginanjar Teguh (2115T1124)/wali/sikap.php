<html>
<head>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
	<title>INPUT DATA NILAI SIKAP</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fid_nilai_sikap	= "";	
$fid_ta				= "";	
$fid_kelas			= "";
$fid_siswa			= "";
$fnama				= "";		
$fijin				= "";	
$fsakit				= "";	
$falpha				= "";	
$fkelakuan			= "";	
$fkerajinan			= "";
$fkerapian			= "";		
?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM nilai_sikap where id_nilai='$_GET[id]'");
$r		= mysql_fetch_array($tampil);
$ftitle				= "<h1>UBAH DATA</h1>";	
$fid_nilai_sikap	= $r['id_nilai'];	
$fid_ta				= $r['id_ta'];	
$fid_kelas			= $r['id_kelas'];	
$fid_siswa			= $r['id_siswa'];
$fnama 				= $r['nama'];		
$fijin				= $r['ijin'];	
$fsakit				= $r['sakit'];	
$falpha				= $r['alpha'];
$fkelakuan			= $r['kelakuan'];
$fkerajinan			= $r['kerajinan'];
$fkerapian			= $r['kerapian'];	

}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>INPUT NILAI SIKAP</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fid_nilai_sikap ?>">
	<?php } 	?>
	<table>
	<tr><td>ID NILAI SIKAP	</td><td><input type="text" name="id_nilai" value="<?= $fid_nilai_sikap?>"></td></tr>
	<tr><td>ID TAHUN AJARAN	</td><td><input type="text" name="id_ta" value="<?= $fid_ta ?>"></td></tr>
	<tr><td>ID KELAS		</td><td><input type="text" name="id_kelas" value="<?= $fid_kelas ?>"></td></tr>
	<tr><td>NIS				</td><td><input type="text" name="id_siswa" value="<?= $fid_siswa ?>"></td></tr>
	<tr><td>NAMA			</td><td><input type="text" name="nama" value="<?= $fnama ?>"></td></tr>
	<tr><td>IJIN			</td><td><input type="text" name="ijin" value="<?= $fijin ?>"></td></tr>
	<tr><td>SAKIT			</td><td><input type="text" name="sakit" value="<?= $fsakit?>"></td></tr>
	<tr><td>ALPHA			</td><td><input type="text" name="alpha" value="<?= $falpha ?>"></td></tr>
	<tr><td>KELAKUAN</td>
	<td>	
			<?php if($fkelakuan =="A"){ ?>
			<input type="radio" name="kelakuan" value="A" checked>A</input>
			<?php }else{ ?>
			<input type="radio" name="kelakuan" value="A">A</input>
			<?php } ?>
			
			<?php if($fkelakuan =="B"){ ?>
			<input type="radio" name="kelakuan" value="B" checked>B</input>
			<?php }else{ ?>
			<input type="radio" name="kelakuan" value="B">B</input>
			<?php } ?>
			
			<?php if($fkelakuan =="C"){ ?>
			<input type="radio" name="kelakuan" value="C" checked>C</input>
			<?php }else{ ?>
			<input type="radio" name="kelakuan" value="C">C</input>
			<?php } ?>
			
	</td></tr>
	<tr><td>KERAJINAN</td>
	<td>	
			<?php if($fkerajinan =="A"){ ?>
			<input type="radio" name="kerajinan" value="A" checked>A</input>
			<?php }else{ ?>
			<input type="radio" name="kerajinan" value="A">A</input>
			<?php } ?>
			
			<?php if($fkerajinan =="B"){ ?>
			<input type="radio" name="kerajinan" value="B" checked>B</input>
			<?php }else{ ?>
			<input type="radio" name="kerajinan" value="B">B</input>
			<?php } ?>
			
			<?php if($fkerajinan =="C"){ ?>
			<input type="radio" name="kerajinan" value="C" checked>C</input>
			<?php }else{ ?>
			<input type="radio" name="kerajinan" value="C">C</input>
			<?php } ?>
						
	</td></tr>
	<tr><td>KERAPIAN</td>
	<td>	
			<?php if($fkerapian =="A"){ ?>
			<input type="radio" name="kerapian" value="A" checked>A</input>
			<?php }else{ ?>
			<input type="radio" name="kerapian" value="A">A</input>
			<?php } ?>
			
			<?php if($fkerapian =="B"){ ?>
			<input type="radio" name="kerapian" value="B" checked>B</input>
			<?php }else{ ?>
			<input type="radio" name="kerapian" value="B">B</input>
			<?php } ?>
			
			<?php if($fkerapian =="C"){ ?>
			<input type="radio" name="kerapian" value="C" checked>C</input>
			<?php }else{ ?>
			<input type="radio" name="kerapian" value="C">C</input>
			<?php } ?>
	</td></tr>
	<tr><td colspan="2" align="center"><input type="submit" name="submit" 	value="INPUT"> <input  type="button" value="BATAL" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['id_nilai'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO nilai_sikap(id_nilai, id_ta, id_kelas, id_siswa, nama, ijin, sakit, alpha ,kelakuan, kerajinan, kerapian )
					
					VALUES ('$_POST[id_nilai]','$_POST[id_ta]','$_POST[id_kelas]','$_POST[id_siswa]','$_POST[nama]','$_POST[ijin]','$_POST[sakit]','$_POST[alpha]','$_POST[kelakuan]','$_POST[kerajinan]','$_POST[kerapian]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE nilai_sikap SET id_nilai = '$_POST[id_nilai]',id_ta = '$_POST[id_ta]',id_kelas = '$_POST[id_kelas]',id_siswa = '$_POST[id_siswa]',nama = '$_POST[nama]',ijin= '$_POST[ijin]',sakit= '$_POST[sakit]',alpha= '$_POST[alpha]',kelakuan= '$_POST[kelakuan]',kerajinan= '$_POST[kerajinan]',kerapian= '$_POST[kerapian]' WHERE id_nilai  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM nilai_sikap WHERE id_nilai='$_GET[id]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<h1>INPUT DATA SIKAP</h1>
<table align="center">
<tr>
<td><button onclick="window.location.href='../wali/input.php'">UPDATE</button></td>
<td><button onclick="window.location.href='../login/walikelas.php'">BERANDA</button></td>
<tr>
</table>
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>
