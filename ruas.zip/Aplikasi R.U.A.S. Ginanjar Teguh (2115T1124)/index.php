<html>
<title>
R.U.A.S
</title>
<head>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<br>
<h1>RAPORT UJIAN AKHIR SEMESTER</h1>
<br>
</head>
<body>
<hr>
<table width="510" border="0" align="center">
		 <tr>
			 <td width="60" height="60" align="center">
				<img width=90 height=90 src='./style/bg/bg1.png' />
			 </td>
			 <td width="10"></td>
			 <td><h3>
				<strong>YAYASAN PERGURUAN KRISTEN (YPK)</strong>
				<br><strong>SMK Kristen Purwodadi</strong>
				<br>Jl. D.I Panjaitan No. 2-4 Purwodadi - Grobogan
				<br>Telp. (0292) 421244 email : smkkrpwd@gmail.com
				</h3>
			 </td>
		 </tr>
</table>
<hr>
<br>
<br>
<form action="login/login.php" class="form-horizontal" method="post">
<table align='center'>
<tr>
	<td>
		<label class="username">Username</label>
	</td>
	<td>
		<input name="username" placeholder="Username Anda" type="text" />
	</td>
</tr>
<tr>
	<td>
    <label class="password">Password</label>        
	</td>
	<td>
    <input name="pass" placeholder="Password" type="password" />
	</td>	
</tr>
<tr>
	<td>
	</td>
	<td>
	<button class="btn" name="submit" type="submit">Login</button>
	</td>
</tr>	
</form>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</body>
</html>