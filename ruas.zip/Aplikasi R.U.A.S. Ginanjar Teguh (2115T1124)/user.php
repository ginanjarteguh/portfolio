<html>
<head>
<br>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<title>DATA USER</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fusername			= "";	
$fid_pegawai		= "";	
$fpassword			= "";	
$flevel				= "";	

?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM user where username='$_GET[id]'");
$r		= mysql_fetch_array($tampil);
$ftitle		= "<h1>UBAH DATA</h1>";	
$fusername	= $r['username'];	
$fid_pegawai= $r['id_pegawai'];	
$fpassword	= $r['password'];	
$flevel		= $r['level'];	

}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>INPUT DATA USER</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fusername ?>">
	<?php } 	?>
	<table>
	<h3 align="center">user</h3>
	<tr><td>USERNAME</td><td><input type="text" name="username" value="<?= $fusername ?>"></td></tr>
	<tr><td>ID PEGAWAI</td><td><input type="text" name="id_pegawai" value="<?= $fid_pegawai ?>"></td></tr>
	<tr><td>PASSWORD</td><td><input type="text" name="password" value="<?= $fpassword ?>"></td></tr>
	<tr><td>LEVEL</td><td>
			<select name="level">
				<?php if($_GET["op"] == "edit"){ ?>
				<option value="<?= $flevel ?>"><?= $flevel ?></option>
				<?php }else{ ?>
				<option> - Pilih Level - </option>
				<?php } ?>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
			</select>
			
	</td></tr>
	
	<tr><td colspan="2" align="center"><input type="submit" name="submit" value="DAFTAR"> <input  type="button" value="BATAL" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['username'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO user (username, id_pegawai, password ,level) VALUES ('$_POST[username]','$_POST[id_pegawai]','$_POST[password]','$_POST[level]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE user SET username = '$_POST[username]',id_pegawai = '$_POST[id_pegawai]',password = '$_POST[password]',level = '$_POST[level]' WHERE username  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM user WHERE username='$_GET[id]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<center>
<h1>input user</h1>
<a href='<?= $_SERVER['PHP_SELF'] ?>'>Index</a> | <a href='?op=tambah'>Tambah </a> | <a href='login/index.php'>Beranda</a><br><br>
</center>
<table width="70%" border="1" style="margin: 0 auto;">
<tr>
<td>No</td>
<td>USERNAME</td>
<td>ID PEGAWAI</td>
<td>PASSWORD</td>
<td>LEVEL</td>
<td>Operasi</td>
</tr>

<?php
	$tampil=mysql_query("SELECT * FROM user ORDER BY username ASC"); // query sql
	$no=1;
	while ($r=mysql_fetch_array($tampil)){ 							//perulangan menampilkan data
	echo "
			<tr>
				<td>$no</td>
				<td>$r[username]</td>
				<td>$r[id_pegawai]</td>
				<td>$r[password]</td>
				<td>$r[level]</td>
				<td>
				<a href='?op=edit&id=$r[username]'>Edit</a>
				<a href='?op=hapus&id=$r[username]'>Hapus</a>
				</td>
			</tr>
		";
	$no++;
	}
?>
</table>
</body>
</html>
