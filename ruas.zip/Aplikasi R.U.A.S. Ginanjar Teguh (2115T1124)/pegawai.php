<html>
<head>
<br>
<link rel="stylesheet" href="style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<title>DATA PEGAWAI</title>
</head>
<body>
<?php	
error_reporting(0);
ob_start();					
//koneksi
$server = "localhost";		//server
$user 	= "root";			//user
$pass 	= "";				//pass
$db 	= "nilai";			//database

mysql_connect($server,$user,$pass) or die("Mati"); 	//koneksi ke server 
mysql_select_db($db) or die("DB Mati"); 			//koneksi database
?>
<?php
// memilik aksi crud berdasar/ mengambil dari var "OP" pada url
if($_GET["op"] == "tambah"){
	
$fid_pegawai		= "";	
$fnama_guru			= "";	
$fnip				= "";	
$fstatus			= "";	
$ftingkat			= "";	
$fid_jurusan		= "";	
$fid_mapel			= "";	

?>
<?php
}elseif($_GET['op'] == "edit"){
//mengambil baris record yg akan diubah berdasarkan ID record
$tampil	= mysql_query("SELECT * FROM pegawai where id_pegawai='$_GET[id]'");
$r		= mysql_fetch_array($tampil);
$ftitle			= "<h3 align=center>UBAH DATA</h3>";	
$fid_pegawai	= $r['id_pegawai'];	
$fnama_guru		= $r['nama_guru'];	
$fnip			= $r['nip'];	
$fstatus		= $r['status'];	
$ftingkat		= $r['tingkat'];	
$fid_jurusan	= $r['id_jurusan'];	
$fid_mapel		= $r['id_mapel'];	

}
if($_GET["op"] == "tambah" || $_GET["op"] == "edit"){
?>


<table border="1" style="padding:5px; margin: 0 auto;">
<tr>
	<td align="center">
	<h2>INPUT DATA PEGAWAI</h2>
	</td>
</tr>
<tr>
	<td>

	<!-- form -->
	<?= $ftitle ?>
	<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>?op=<?= $_GET["op"] ?>">
	<?php if($_GET["op"] == "edit"){ ?>
	<input type="hidden" name="id" value="<?= $fid_pegawai ?>">
	<?php } 	?>
	<table>
	
	<tr><td>ID PEGAWAI</td><td><input type="text" name="id_pegawai" value="<?= $fid_pegawai ?>"></td></tr>
	<tr><td>NAMA GURU</td><td><input type="text" name="nama_guru" value="<?= $fnama_guru ?>"></td></tr>
	<tr><td>NIP</td><td><input type="text" name="nip" value="<?= $fnip ?>"></td></tr>
	<tr><td>STATUS</td><td>
			<select name="status">
				<?php if($_GET["op"] == "edit"){ ?>
				<option value="<?= $fstatus ?>"><?= $fstatus ?></option>
				<?php }else{ ?>
				<option> - Status - </option>
				<?php } ?>
				<option value="Guru">Guru</option>
				<option value="Karyawan">Karyawan</option>
			</select>

	</td></tr>
	<tr><td>Tingkat</td>
	<td>	
			<?php if($ftingkat =="X"){ ?>
			<input type="radio" name="tingkat" value="X" checked>X</input>
			<?php }else{ ?>
			<input type="radio" name="tingkat" value="X">X</input>
			<?php } ?>
			
			<?php if($ftingkat =="XII"){ ?>
			<input type="radio" name="tingkat" value="XI" checked>XI</input>
			<?php }else{ ?>
			<input type="radio" name="tingkat" value="XI">XI</input>
			<?php } ?>
			
			<?php if($ftingkat =="XII"){ ?>
			<input type="radio" name="tingkat" value="XII" checked>XII</input>
			<?php }else{ ?>
			<input type="radio" name="tingkat" value="XII">XII</input>
			<?php } ?>
						
	</td></tr>
	<tr><td>ID JURUSAN</td>
	<td>	
			<?php if($fid_jurusan =="118"){ ?>
			<input type="radio" name="id_jurusan" value="118" checked>AK</input>
			<?php }else{ ?>
			<input type="radio" name="id_jurusan" value="118">AK</input>
			<?php } ?>
			
			<?php if($fid_jurusan =="119"){ ?>
			<input type="radio" name="id_jurusan" value="119" checked>AP</input>
			<?php }else{ ?>
			<input type="radio" name="id_jurusan" value="119">AP</input>
			<?php } ?>
			
			<?php if($fid_jurusan =="121"){ ?>
			<input type="radio" name="id_jurusan" value="121" checked>PM</input>
			<?php }else{ ?>
			<input type="radio" name="id_jurusan" value="121">PM</input>
			<?php } ?>
						
	</td></tr>
	<tr><td>ID MAPEL</td><td><input type="text" name="id_mapel" value="<?= $fid_mapel ?>"></td></tr>
	<tr><td colspan="2" align="center"><input type="submit" name="submit" 	value="INPUT"> <input  type="button" value="BATAL" onclick="self.history.back()"></td></tr>
	</table>				
	</form>

	<!-- end form -->

	</td>
</tr>
</table>
<?php
}

if(isset($_POST['submit']) && !empty($_POST['id_pegawai'])){
	
	if ($_GET['op'] 		== "tambah"){ 	//input
		mysql_query("INSERT INTO pegawai(id_pegawai, nama_guru, nip ,status, tingkat, id_jurusan, id_mapel) VALUES ('$_POST[id_pegawai]','$_POST[nama_guru]','$_POST[nip]','$_POST[status]','$_POST[tingkat]','$_POST[id_jurusan]','$_POST[id_mapel]')");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}elseif ($_GET['op'] 	== "edit"){  	//ubah
		mysql_query("UPDATE pegawai SET id_pegawai = '$_POST[id_pegawai]',nama_guru = '$_POST[nama_guru]',nip = '$_POST[nip]',status = '$_POST[status]',tingkat = '$_POST[tingkat]',id_jurusan = '$_POST[id_jurusan]',id_mapel = '$_POST[id_mapel]' WHERE id_pegawai  = '$_POST[id]'");
		header('location:'.$_SERVER['PHP_SELF']);
		
	}
}elseif($_GET['op'] 	== "hapus"){		//hapus
		mysql_query("DELETE FROM pegawai WHERE id_pegawai='$_GET[id]'");						
		header('location:'.$_SERVER['PHP_SELF']);
}
	
?>
<center>
<h1>DAFTAR PEGAWAI</h1>
<a href='<?= $_SERVER['PHP_SELF'] ?>'>Index</a> | <a href='?op=tambah'>Tambah</a> | <a href='login/admin.php'>Beranda</a><br><br>
</center>
<table width="70%" border="1" style="margin: 0 auto;">
<tr>
<th>No</th>
<th>ID PEGAWAI</th>
<th>NAMA GURU</th>
<th>NIP</th>
<th>STATUS</th>
<th>tingkat</th>
<th>ID JURUSAN</th>
<th>ID MAPEL</th>
<th>Operasi</th>
</tr>

<?php
	$tampil=mysql_query("SELECT * FROM pegawai ORDER BY id_pegawai ASC"); // query sql
	$no=1;
	while ($r=mysql_fetch_array($tampil)){ 							//perulangan menampilkan data
	echo "
			<tr>
				<td>$no</td>
				<td>$r[id_pegawai]</td>
				<td>$r[nama_guru]</td>
				<td>$r[nip]</td>
				<td>$r[status]</td>
				<td>$r[tingkat]</td>
				<td>$r[id_jurusan]</td>
				<td>$r[id_mapel]</td>
				<td>
				<a href='?op=edit&id=$r[id_pegawai]'>Edit</a>
				<a href='?op=hapus&id=$r[id_pegawai]'>Hapus</a>
				</td>
			</tr>
		";
	$no++;
	}
?>
</table>
</body>
</html>
