<html>
<title>
GURU
</title>
<head>
<br>
<link rel="stylesheet" href="../style/style.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<h1>RAPORT UJIAN AKHIR SEMESTER</h1>
<hr>
</head>
<body>
<?php
error_reporting(0);
session_start();
if (isset($_SESSION['level']))
{
 
   if ($_SESSION['level'] == "admin")
   {
      include 'konten-admin.php';
   }
   else if ($_SESSION['level'] == "user")
   {
       include 'konten-user.php';
   }
}
?>
<table width="1036" border="0" align="center">
		 <tr>
			 <td width="213" height="60" align="center">
				<img width=90 height=90 src='../style/bg/bg1.png' />
			 </td>
			 <td><h3>
				<strong>YAYASAN PERGURUAN KRISTEN (YPK)</strong>
				<br><strong>SMK Kristen Purwodadi</strong>
				<br>Jl. D.I Panjaitan No. 2-4 Purwodadi
				<br>Telp. (0292) 421244 email : smkkrpwd@gmail.com
				</h3>
			 </td>
		 </tr>
</table>
<hr>
<table width="1036" border='0'align="center">
  <tr>
		<td width="213"><div align="center"><img width=120px height=40px src='../style/img/ruas.png'/></div></td>
		<td width="50" align="center">
		<button onclick="window.location.href='#'">BERANDA</button>
		</td>
		<td width="50" align="center">
		<button onclick="window.location.href='../guru/input.php'">NILAI</button>
		</td>
		<td width="50" align="center">
		<button onclick="window.location.href='../kkm/input.php'">KKM</button>
		</td>
		<td width="50" align="center">
		<button onclick="window.location.href='./logout.php'">KELUAR</button>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		
  </tr>
    <tr border="1">
   	<td align="center"><strong>Hari/Tanggal:</strong>
	<br><?php
		$bulan = array(1 => "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
		$hari = array("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu");
		$cetak_date = $hari[(int)date("w")] .', '. date("j ") . $bulan[(int)date('m')] . date(" Y");
		 
		echo $cetak_date;
		?>
	</td>
	<td colspan="8">
	<?php $qguru     	= "SELECT nama_guru FROM pegawai, user WHERE pegawai.id_pegawai=user.id_pegawai AND user.password='$kls'";
			$qhasil		= mysql_query($qguru);
			$guru	    = mysql_fetch_array($qhasil);

			$tampilwali=$guru['nama_guru'];
	?>
	<p>Hallo Guru <br>Selamat Datang di Aplikasi Pengolah Nilai Raport Ujian Akhir Sekolah (R.U.A.S) aplikasi ini dibuat dengan tujuan untuk membantu Guru dan Walikelas dalam menginput dan mencetak hasil raport pada akhir semester.</p></td>
  </tr>
</table>
</body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>  
<h2><strong>R.U.A.S</h2>
<h2>Copyright @ ginanjar teguh</h2>
</html>